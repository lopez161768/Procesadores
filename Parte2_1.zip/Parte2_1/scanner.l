 //Archivo: scanner.l
 //Scanner que reconoce todos los tokens de un archivo con texto.
 // Si es token multivaluado muestra su valor
 //Autor: Saray Lopez y Diana Manevska
 //Fecha: 28/9/2026
 //Version: 0.0.4



%{
	// Headers standard necesarios
	#include <stdio.h> //Para poder escribir en el terminal
	#include <stdlib.h> //Para usar exit()
	#include <string.h> //Para trabajar con cadenas de caracteres

	// Headers creados para este ejemplo
	#include "nombresDeTipos.h" // Para saber los nombres de los tipos
	#include "literal.h" //Para poder usar el tipo Literal
	#include "parser.tab.h" // Lo crea automaticamente bison con la opcion -v
	#include "tablaDeConstantes.h"

	void errorEnScanner(char*, char*); //prototipo necesario para compilar

%}

%option noyywrap


falsoDR	(?i:falso)
constDR (?i:const)
fconstDR (?i:fconst)
accionDR (?i:accion)
algoritmoDR (?i:algoritmo)
booleanoDR (?i:booleano)
cadenaDR (?i:cadena)
caracterDR (?i:caracter)
continuarDR (?i:continuar)
deDR (?i:de)
devDR (?i:dev)
divDR (?i:div)
entDR (?i:ent)
enteroDR (?i:entero)
entSalDR (?i:e\/s)
faccionDR (?i:faccion)
falgoritmoDR (?i:falgoritmo)
ffuncionDR (?i:ffuncion)
fmientrasDR (?i:fmientras)
fparaDR (?i:fpara)
fsiDR (?i:fsi)
ftipoDR (?i:ftipo)
ftuplaDR (?i:ftupla)
funcionDR (?i:funcion)
fvarDR (?i:fvar)
hacerDR (?i:hacer)
hastaDR (?i:hasta)
mientrasDR (?i:mientras)
modDR (?i:mod)
noDR (?i:no)
oDR (?i:o)
paraDR (?i:para)
realDR (?i:real)
refDR (?i:ref)
salDR (?i:sal)
siDR (?i:si)
tablaDR (?i:tabla)
tipoDR (?i:tipo)
tuplaDR (?i:tupla)
varDR (?i:var)
verdaderoDR	(?i:verdadero)
yDR (?i:y)

igualDR	=

literalCaracterDR	\".\"
literalCadenaDR	'([^']|\/')*'

comentarioDR	\{([^\}]|\/\})*\}

nombreCteDR	[A-Z]+

exponenteDR	[eE][0-9]+
literalEnteroDR	[0-9]+({exponenteDR})?
literalRealDR	({literalEnteroDR}[rR])|([0-9]+\.[0-9]+({exponenteDR})?)

letraDR             [a-zA-Z]
cifraDR             [0-9]
letra_o_cifraDR     [a-zA-Z0-9]
identificadorDR     {letraDR}{letra_o_cifraDR}*

puntoYComaDR	;
dosPuntosDR :
asignacionDR	:=
puntoDR	\.
subrangoDR	\.\.
comaDR \,
operadorDivisionDR	\/
operadorDistintoDR	<>
siNoDR	\[\]
operadorMayorIgualDR	>=
operadorMenorIgualDR	<=
operadorMenorDR	<
operadorMayorDR	>
entoncesDR	->
corcheteAbiertoDR	\[
corcheteCerradoDR	\]
parentesisAbiertoDR	\(
parentesisCerradoDR	\)

%%

{constDR}	{	return constTK;	}
{falsoDR}	{
	//Para programar de modo mas claro el parser, se ha optado por unir todos
	//los tokens de literales en un token unico. Hace necesario el modulo cuyo
	//header es literal.h
	//Esta eleccion permite ejemplificar el uso del %union y los union de C
	yylval.literal.tipoDelValor = BOOLEANO;
	yylval.literal.valor.valorBooleano = FALSO;
	return literalTK;
}
{verdaderoDR}	{
	yylval.literal.tipoDelValor = BOOLEANO;
	yylval.literal.valor.valorBooleano = VERDADERO;
	return literalTK;
}
{fconstDR}	{	return fconstTK;	}
{accionDR}	{	return accionTK;	}
{algoritmoDR}	{	return algoritmoTK;	}
{booleanoDR}	{	return booleanoTK;	}
{cadenaDR}	{ 	return cadenaTK; }
{caracterDR}	{ 	return caracterTK; }
{continuarDR}	{	return continuarTK;	}
{deDR}	{	return deTK;	}
{devDR}	{	return devTK;	}
{divDR}	{	return divTK;	}
{entDR}	{	return entTK;	}
{enteroDR}	{	return enteroTK;	}
{entSalDR}	{	return entSalTK;	}
{faccionDR}	{	return faccionTK;	}
{falgoritmoDR}	{	return falgoritmoTK;	}
{ffuncionDR}	{	return ffuncionTK;	}
{fmientrasDR}	{	return fmientrasTK;	}
{fparaDR}	{	return fparaTK;	}
{fsiDR}	{	return fsiTK;	}
{ftipoDR}	{	return ftipoTK;	}
{ftuplaDR}	{	return ftuplaTK;	}
{funcionDR}	{	return funcionTK;	}
{fvarDR}	{	return fvarTK;	}
{hacerDR}	{	return hacerTK;	}
{hastaDR}	{	return hastaTK;	}
{mientrasDR}	{	return mientrasTK;	}
{modDR}	{	return modTK;	}
{noDR}	{	return noTK;	}
{oDR}	{	return oTK;	}
{paraDR}	{	return paraTK;	}
{realDR}	{	return realTK;	}
{refDR}	{	return refTK;	}
{salDR}	{	return salTK;	}
{siDR}	{	return siTK;	}
{tablaDR}	{	return tablaTK;	}
{tipoDR}	{	return tipoTK;	}
{tuplaDR}	{	return tuplaTK;	}
{varDR}	{	return varTK;	}
{yDR}	{	return yTK;	}


{igualDR}	{	return igualTK;	}

-	{	return operadorRestaTK;	}
\+	{	return operadorSumaTK;	}
"*"	{	return operadorProductoTK;	}


{literalCadenaDR}	{
	yylval.literal.tipoDelValor = CADENA;
	yylval.literal.valor.valorCadena = strndup(yytext + 1, yyleng - 2);

	return literalTK;
}

{literalCaracterDR}	{
	yylval.literal.tipoDelValor = CARACTER;
	yylval.literal.valor.valorCaracter = yytext[1]; //no estoy segura de si está bien

	return literalTK;
}

{literalEnteroDR} {
	if (strchr(yytext, 'e') != NULL || strchr(yytext, 'E') != NULL) {
		yylval.literal.tipoDelValor = ENTERO;
		yylval.literal.valor.valorEntero = strtod(yytext, NULL);
		return literalTK;
    }
	else {
		yylval.literal.tipoDelValor = ENTERO;
		yylval.literal.valor.valorEntero = atoll(yytext);
		return literalTK;
    }
}

{literalRealDR}	{
	yylval.literal.tipoDelValor = REAL;
	yylval.literal.valor.valorReal = atof(yytext);

	return literalTK;
}

{nombreCteDR}	{
	yylval.cadena = strdup(yytext);

	return nombreCteTK;
}

{comentarioDR}	{
	yylval.cadena = strndup(yytext + 1, yyleng - 2);

	return comentarioTK;

}


{identificadorDR} {
	yylval.cadena = strdup(yytext);

	return identificadorTK;
}


{puntoYComaDR}	{	return puntoYComaTK;	}
{dosPuntosDR}   {    return dosPuntosTK;	}
{asignacionDR}	{	return asignacionTK;	}
{puntoDR}   {    return puntoTK;	}
{subrangoDR}	{	return subrangoTK;	}
{comaDR}	{	return comaTK;	}
{operadorDivisionDR}	{	return operadorDivisionTK;	}

{operadorDistintoDR}	{ return operadorDistintoTK; }
{siNoDR}    { return siNoTK; }
{operadorMayorIgualDR}    { return operadorMayorIgualTK; }
{operadorMenorIgualDR}    { return operadorMenorIgualTK; }
{entoncesDR}	{	return entoncesTK;	}

{operadorMenorDR}     {	return operadorMenorTK; }
{operadorMayorDR}     {	return operadorMayorTK; }
{corcheteAbiertoDR}     {	return corcheteAbiertoTK; }
{corcheteCerradoDR}     {	return corcheteCerradoTK; }
{parentesisAbiertoDR}     {	return parentesisAbiertoTK; }
{parentesisCerradoDR}     {	return parentesisCerradoTK; }

[ \t\n\r]+            //Ignorar espacios en blanco, tabuladores y saltos de línea

.	{ //Permite que el resto de caracteres no hagan echo
}

%%

void errorEnScanner(char* definicionDelError, char * variable){
	printf("\n\n\n\t%s %s \n", definicionDelError, variable);
	exit(EXIT_FAILURE);
}


/* main para leer ficheros .alg
int main(int argc, char *argv[]){
	if (argc > 1){
		FILE *archivo = fopen(argv[1], "r");

		if (!archivo) {
            perror("Error al abrir el archivo de entrada");
            return 1;
        }

        yyin = archivo;
	}

	yylex();

	if (argc > 1) {
		fclose(yyin);
	}

	return 0;
}
*/
