/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 11 "parser.y"

	#include <stdio.h>
	#include "nombresDeTipos.h"
	#include "literal.h"
	#include "tablaDeConstantes.h"

	int yylex(); // Usamos la funcion que se crea gracias a flex
	void yyerror(char *); // Prototipo de una funcion necesaria
	extern FILE* yyin; // Usamos la varible de Flex en la que viene la entrada

	TablaDeConstantes tc; //Es donde guardaremos las constantes
	#define YYDEBUG 1 //Permite activar el modo Debugg de Bison

#line 85 "parser.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_literalTK = 3,                  /* literalTK  */
  YYSYMBOL_nombreCteTK = 4,                /* nombreCteTK  */
  YYSYMBOL_identificadorTK = 5,            /* identificadorTK  */
  YYSYMBOL_identificadorTK_b = 6,          /* identificadorTK_b  */
  YYSYMBOL_comentarioTK = 7,               /* comentarioTK  */
  YYSYMBOL_constTK = 8,                    /* constTK  */
  YYSYMBOL_fconstTK = 9,                   /* fconstTK  */
  YYSYMBOL_accionTK = 10,                  /* accionTK  */
  YYSYMBOL_algoritmoTK = 11,               /* algoritmoTK  */
  YYSYMBOL_booleanoTK = 12,                /* booleanoTK  */
  YYSYMBOL_cadenaTK = 13,                  /* cadenaTK  */
  YYSYMBOL_caracterTK = 14,                /* caracterTK  */
  YYSYMBOL_continuarTK = 15,               /* continuarTK  */
  YYSYMBOL_deTK = 16,                      /* deTK  */
  YYSYMBOL_devTK = 17,                     /* devTK  */
  YYSYMBOL_divTK = 18,                     /* divTK  */
  YYSYMBOL_entTK = 19,                     /* entTK  */
  YYSYMBOL_enteroTK = 20,                  /* enteroTK  */
  YYSYMBOL_entSalTK = 21,                  /* entSalTK  */
  YYSYMBOL_faccionTK = 22,                 /* faccionTK  */
  YYSYMBOL_falgoritmoTK = 23,              /* falgoritmoTK  */
  YYSYMBOL_ffuncionTK = 24,                /* ffuncionTK  */
  YYSYMBOL_fmientrasTK = 25,               /* fmientrasTK  */
  YYSYMBOL_fparaTK = 26,                   /* fparaTK  */
  YYSYMBOL_fsiTK = 27,                     /* fsiTK  */
  YYSYMBOL_ftipoTK = 28,                   /* ftipoTK  */
  YYSYMBOL_ftuplaTK = 29,                  /* ftuplaTK  */
  YYSYMBOL_funcionTK = 30,                 /* funcionTK  */
  YYSYMBOL_fvarTK = 31,                    /* fvarTK  */
  YYSYMBOL_hacerTK = 32,                   /* hacerTK  */
  YYSYMBOL_hastaTK = 33,                   /* hastaTK  */
  YYSYMBOL_mientrasTK = 34,                /* mientrasTK  */
  YYSYMBOL_modTK = 35,                     /* modTK  */
  YYSYMBOL_noTK = 36,                      /* noTK  */
  YYSYMBOL_oTK = 37,                       /* oTK  */
  YYSYMBOL_paraTK = 38,                    /* paraTK  */
  YYSYMBOL_realTK = 39,                    /* realTK  */
  YYSYMBOL_refTK = 40,                     /* refTK  */
  YYSYMBOL_salTK = 41,                     /* salTK  */
  YYSYMBOL_siTK = 42,                      /* siTK  */
  YYSYMBOL_tablaTK = 43,                   /* tablaTK  */
  YYSYMBOL_tipoTK = 44,                    /* tipoTK  */
  YYSYMBOL_tuplaTK = 45,                   /* tuplaTK  */
  YYSYMBOL_varTK = 46,                     /* varTK  */
  YYSYMBOL_yTK = 47,                       /* yTK  */
  YYSYMBOL_igualTK = 48,                   /* igualTK  */
  YYSYMBOL_operadorRestaTK = 49,           /* operadorRestaTK  */
  YYSYMBOL_operadorSumaTK = 50,            /* operadorSumaTK  */
  YYSYMBOL_operadorProductoTK = 51,        /* operadorProductoTK  */
  YYSYMBOL_operadorDivisionTK = 52,        /* operadorDivisionTK  */
  YYSYMBOL_puntoYComaTK = 53,              /* puntoYComaTK  */
  YYSYMBOL_dosPuntosTK = 54,               /* dosPuntosTK  */
  YYSYMBOL_asignacionTK = 55,              /* asignacionTK  */
  YYSYMBOL_puntoTK = 56,                   /* puntoTK  */
  YYSYMBOL_subrangoTK = 57,                /* subrangoTK  */
  YYSYMBOL_comaTK = 58,                    /* comaTK  */
  YYSYMBOL_operadorDistintoTK = 59,        /* operadorDistintoTK  */
  YYSYMBOL_siNoTK = 60,                    /* siNoTK  */
  YYSYMBOL_operadorMayorIgualTK = 61,      /* operadorMayorIgualTK  */
  YYSYMBOL_operadorMenorIgualTK = 62,      /* operadorMenorIgualTK  */
  YYSYMBOL_operadorMenorTK = 63,           /* operadorMenorTK  */
  YYSYMBOL_operadorMayorTK = 64,           /* operadorMayorTK  */
  YYSYMBOL_entoncesTK = 65,                /* entoncesTK  */
  YYSYMBOL_corcheteAbiertoTK = 66,         /* corcheteAbiertoTK  */
  YYSYMBOL_corcheteCerradoTK = 67,         /* corcheteCerradoTK  */
  YYSYMBOL_parentesisAbiertoTK = 68,       /* parentesisAbiertoTK  */
  YYSYMBOL_parentesisCerradoTK = 69,       /* parentesisCerradoTK  */
  YYSYMBOL_YYACCEPT = 70,                  /* $accept  */
  YYSYMBOL_desc_algoritmo = 71,            /* desc_algoritmo  */
  YYSYMBOL_cabecera_alg = 72,              /* cabecera_alg  */
  YYSYMBOL_bloque_alg = 73,                /* bloque_alg  */
  YYSYMBOL_decl_globales = 74,             /* decl_globales  */
  YYSYMBOL_decl_a_f = 75,                  /* decl_a_f  */
  YYSYMBOL_bloque = 76,                    /* bloque  */
  YYSYMBOL_declaraciones = 77,             /* declaraciones  */
  YYSYMBOL_declaracion_tipo = 78,          /* declaracion_tipo  */
  YYSYMBOL_declaracion_const = 79,         /* declaracion_const  */
  YYSYMBOL_declaracion_var = 80,           /* declaracion_var  */
  YYSYMBOL_lista_d_tipo = 81,              /* lista_d_tipo  */
  YYSYMBOL_d_tipo = 82,                    /* d_tipo  */
  YYSYMBOL_tipo_base = 83,                 /* tipo_base  */
  YYSYMBOL_expresion_t = 84,               /* expresion_t  */
  YYSYMBOL_lista_campos = 85,              /* lista_campos  */
  YYSYMBOL_lista_d_cte = 86,               /* lista_d_cte  */
  YYSYMBOL_lista_d_var = 87,               /* lista_d_var  */
  YYSYMBOL_lista_id = 88,                  /* lista_id  */
  YYSYMBOL_decl_ent_sal = 89,              /* decl_ent_sal  */
  YYSYMBOL_decl_ent = 90,                  /* decl_ent  */
  YYSYMBOL_decl_sal = 91,                  /* decl_sal  */
  YYSYMBOL_expresion = 92,                 /* expresion  */
  YYSYMBOL_exp_a = 93,                     /* exp_a  */
  YYSYMBOL_exp_b = 94,                     /* exp_b  */
  YYSYMBOL_oprel = 95,                     /* oprel  */
  YYSYMBOL_operando = 96,                  /* operando  */
  YYSYMBOL_operando_b = 97,                /* operando_b  */
  YYSYMBOL_instrucciones = 98,             /* instrucciones  */
  YYSYMBOL_instruccion = 99,               /* instruccion  */
  YYSYMBOL_asignacion = 100,               /* asignacion  */
  YYSYMBOL_alternativa = 101,              /* alternativa  */
  YYSYMBOL_lista_opciones = 102,           /* lista_opciones  */
  YYSYMBOL_iteracion = 103,                /* iteracion  */
  YYSYMBOL_it_cota_exp = 104,              /* it_cota_exp  */
  YYSYMBOL_it_cota_fija = 105,             /* it_cota_fija  */
  YYSYMBOL_accion_d = 106,                 /* accion_d  */
  YYSYMBOL_funcion_d = 107,                /* funcion_d  */
  YYSYMBOL_a_cabecera = 108,               /* a_cabecera  */
  YYSYMBOL_f_cabecera = 109,               /* f_cabecera  */
  YYSYMBOL_d_par_form = 110,               /* d_par_form  */
  YYSYMBOL_d_p_form = 111,                 /* d_p_form  */
  YYSYMBOL_accion_ll = 112,                /* accion_ll  */
  YYSYMBOL_funcion_ll = 113,               /* funcion_ll  */
  YYSYMBOL_l_ll = 114                      /* l_ll  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   314

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  70
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  45
/* YYNRULES -- Number of rules.  */
#define YYNRULES  106
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  235

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   324


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   140,   140,   143,   146,   149,   150,   151,   154,   155,
     156,   159,   162,   163,   164,   165,   169,   172,   175,   179,
     180,   183,   184,   185,   186,   187,   188,   191,   192,   193,
     194,   195,   198,   199,   202,   203,   207,   208,   211,   212,
     215,   216,   219,   220,   221,   224,   227,   231,   232,   233,
     236,   237,   238,   239,   240,   241,   242,   243,   244,   245,
     246,   249,   250,   251,   252,   253,   254,   255,   258,   259,
     260,   261,   262,   263,   266,   267,   268,   269,   272,   276,
     277,   280,   281,   282,   283,   284,   287,   290,   293,   294,
     297,   298,   301,   304,   308,   311,   314,   317,   320,   321,
     324,   325,   326,   329,   332,   335,   336
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "literalTK",
  "nombreCteTK", "identificadorTK", "identificadorTK_b", "comentarioTK",
  "constTK", "fconstTK", "accionTK", "algoritmoTK", "booleanoTK",
  "cadenaTK", "caracterTK", "continuarTK", "deTK", "devTK", "divTK",
  "entTK", "enteroTK", "entSalTK", "faccionTK", "falgoritmoTK",
  "ffuncionTK", "fmientrasTK", "fparaTK", "fsiTK", "ftipoTK", "ftuplaTK",
  "funcionTK", "fvarTK", "hacerTK", "hastaTK", "mientrasTK", "modTK",
  "noTK", "oTK", "paraTK", "realTK", "refTK", "salTK", "siTK", "tablaTK",
  "tipoTK", "tuplaTK", "varTK", "yTK", "igualTK", "operadorRestaTK",
  "operadorSumaTK", "operadorProductoTK", "operadorDivisionTK",
  "puntoYComaTK", "dosPuntosTK", "asignacionTK", "puntoTK", "subrangoTK",
  "comaTK", "operadorDistintoTK", "siNoTK", "operadorMayorIgualTK",
  "operadorMenorIgualTK", "operadorMenorTK", "operadorMayorTK",
  "entoncesTK", "corcheteAbiertoTK", "corcheteCerradoTK",
  "parentesisAbiertoTK", "parentesisCerradoTK", "$accept",
  "desc_algoritmo", "cabecera_alg", "bloque_alg", "decl_globales",
  "decl_a_f", "bloque", "declaraciones", "declaracion_tipo",
  "declaracion_const", "declaracion_var", "lista_d_tipo", "d_tipo",
  "tipo_base", "expresion_t", "lista_campos", "lista_d_cte", "lista_d_var",
  "lista_id", "decl_ent_sal", "decl_ent", "decl_sal", "expresion", "exp_a",
  "exp_b", "oprel", "operando", "operando_b", "instrucciones",
  "instruccion", "asignacion", "alternativa", "lista_opciones",
  "iteracion", "it_cota_exp", "it_cota_fija", "accion_d", "funcion_d",
  "a_cabecera", "f_cabecera", "d_par_form", "d_p_form", "accion_ll",
  "funcion_ll", "l_ll", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-144)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-66)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      23,    34,    28,    -9,  -144,    15,    76,   111,     3,    83,
      15,    15,    80,    63,    91,   113,   140,   141,   162,    89,
       3,     3,     3,   168,   170,    50,    83,    83,  -144,  -144,
     176,  -144,    12,  -144,   134,   164,   142,   150,  -144,   125,
    -144,    24,   193,    24,   149,   157,  -144,  -144,  -144,  -144,
    -144,  -144,  -144,  -144,  -144,  -144,   145,     3,   167,     3,
     140,   140,   222,   198,  -144,  -144,  -144,   177,   174,    54,
    -144,  -144,  -144,  -144,  -144,    24,  -144,    12,   178,   235,
      65,    65,    24,   192,  -144,   185,   233,    68,    -6,   172,
    -144,  -144,   140,  -144,    12,  -144,    24,  -144,   179,   138,
     191,   207,  -144,    24,   244,    24,    89,    17,   238,   140,
     247,  -144,  -144,  -144,  -144,    76,    24,   233,   189,  -144,
      61,   211,   232,  -144,  -144,    65,   133,   139,   103,     6,
     111,    61,  -144,  -144,  -144,  -144,  -144,  -144,    24,    65,
      65,    65,    65,    65,    65,    24,    24,  -144,   214,   225,
     206,    89,    24,    89,   233,     5,   195,  -144,   140,   140,
     140,   213,   237,  -144,   216,    24,  -144,   224,   234,    12,
    -144,   103,  -144,  -144,  -144,  -144,   233,    68,    68,   133,
     139,    -2,     2,   189,   189,   140,    24,  -144,   -13,   161,
      42,  -144,   245,   246,   248,   250,    17,   281,   119,  -144,
      61,   251,  -144,  -144,  -144,    24,    24,   274,    12,    12,
      12,  -144,  -144,    12,  -144,   239,   235,   155,   215,  -144,
    -144,  -144,  -144,   252,   291,  -144,    89,    89,  -144,    12,
      -7,    42,  -144,  -144,  -144
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,     0,     0,     1,     7,    37,    20,    15,    10,
       7,     7,     0,     0,     0,     0,    39,     0,     0,     0,
      15,    15,    15,     0,     0,     0,    10,    10,     5,     6,
       0,    17,     0,    16,    41,     0,     0,     0,     4,    74,
      81,     0,     0,     0,     0,    11,    80,    82,    83,    84,
      91,    90,    85,    12,    13,    14,     0,    15,     0,    15,
      39,    39,     0,    42,    44,     8,     9,     0,    58,    74,
      78,    28,    31,    29,    27,     0,    30,     0,     0,    35,
       0,     0,     0,     0,    26,     0,    32,    47,    48,    57,
      64,    49,     0,    18,     0,     2,     0,    58,    74,     0,
       0,     0,    77,     0,     0,     0,     0,    99,     0,    39,
       0,    45,    46,     3,    43,    37,     0,     0,    63,    25,
       0,     0,     0,    58,    74,     0,    59,    60,    47,    48,
      20,     0,    70,    71,    72,    73,    68,    69,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    40,     0,   106,
       0,     0,     0,     0,    86,    75,     0,    79,     0,     0,
       0,     0,     0,    94,     0,     0,    36,     0,     0,     0,
      21,     0,    56,    67,    19,    24,    66,    55,    54,    51,
      50,    52,    53,    62,    61,    39,     0,   103,     0,     0,
      89,    76,     0,     0,     0,     0,    99,     0,     0,   104,
       0,     0,    38,   105,    92,     0,     0,     0,     0,     0,
       0,    96,    98,     0,    95,     0,    35,     0,     0,    87,
     100,   102,   101,     0,     0,    34,     0,     0,    97,     0,
       0,    89,    22,    93,    88
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -144,  -144,  -144,  -144,    98,   123,    67,   212,   137,   166,
    -144,   180,   -73,  -144,  -118,    92,   194,   -55,   -70,  -144,
    -144,   249,   -40,    19,   -68,  -144,   -19,  -144,  -143,   205,
    -144,  -144,    82,  -144,  -144,  -144,  -144,  -144,  -144,  -144,
     118,  -144,  -144,  -144,  -107
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     2,     8,    17,     9,    25,    18,    19,    20,    21,
      22,    15,    83,    84,    85,   122,    13,    35,    36,    62,
      63,    64,    86,    87,    88,   138,    89,    90,    45,    46,
      47,    48,   207,    49,    50,    51,    26,    27,    57,    59,
     161,   162,    52,    91,   150
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      44,    99,   168,   101,   119,   111,   112,   118,   188,   167,
     190,     6,   204,   175,   129,    68,   139,    69,    70,   233,
     139,   148,   147,     6,    71,    72,    73,    97,     4,    98,
      70,   145,    74,   140,     1,   117,   158,   140,   159,     3,
     106,   146,   117,   145,     5,   102,   106,     7,    75,    16,
     144,    76,    77,   146,   164,    78,   149,    79,   160,     7,
      75,    80,    81,   154,    68,   156,    98,    70,   123,    60,
     124,   105,    31,    80,    81,   173,   149,   183,   184,   203,
      82,    12,   215,   230,   231,   155,   139,    44,   192,   193,
     194,    61,    82,    23,    39,   106,   201,    75,   176,   126,
     127,   128,   206,   140,    40,   117,   117,   -23,    28,    29,
      80,    81,   189,    24,    80,    81,    14,   141,   142,   143,
     144,   139,   116,    41,   108,   198,   110,    42,    30,    82,
     202,    43,    44,   125,    44,   220,   221,   222,   140,    32,
     223,    33,    10,   214,   171,    34,   149,    10,    10,    65,
      66,   139,   141,   142,   143,   144,   232,   139,   177,   178,
     179,   180,   181,   182,    37,   217,   218,   132,   140,    38,
     151,    11,   172,    56,   140,    58,    11,    11,   133,    67,
     134,   135,   136,   137,   143,   144,   132,   226,   141,   102,
     143,   144,    92,    96,   205,    93,    94,   133,   100,   134,
     135,   136,   137,   132,   103,   104,    95,    44,    44,   132,
     106,   -65,   102,   107,   133,   105,   134,   135,   136,   137,
     133,   -65,   134,   135,   136,   137,   145,   -33,   104,   113,
     115,   -33,    53,    54,    55,   109,   146,   -48,   105,    61,
     121,   -33,   131,   132,   120,   130,   152,   116,   -48,   124,
     -48,   -48,   -48,   -48,   133,   132,   134,   135,   136,   137,
     163,   170,   191,   132,   165,   169,   133,   185,   134,   135,
     136,   137,   153,   132,   133,   187,   134,   135,   136,   137,
     227,   132,   195,   186,   133,   197,   134,   135,   136,   137,
     196,   200,   133,   199,   134,   135,   136,   137,   213,   208,
     209,   219,   210,   211,   216,   228,   224,   229,   225,   166,
     174,   157,   114,   234,   212
};

static const yytype_uint8 yycheck[] =
{
      19,    41,   120,    43,    77,    60,    61,    75,   151,   116,
     153,     8,    25,   131,    82,     3,    18,     5,     6,    26,
      18,    94,    92,     8,    12,    13,    14,     3,     0,     5,
       6,    37,    20,    35,    11,    75,    19,    35,    21,     5,
      53,    47,    82,    37,    53,    40,    53,    44,    36,    46,
      52,    39,    40,    47,   109,    43,    96,    45,    41,    44,
      36,    49,    50,   103,     3,   105,     5,     6,     3,    19,
       5,    66,     9,    49,    50,    69,   116,   145,   146,   186,
      68,     5,   200,   226,   227,   104,    18,   106,   158,   159,
     160,    41,    68,    10,     5,    53,   169,    36,   138,    80,
      81,    82,    60,    35,    15,   145,   146,    53,    10,    11,
      49,    50,   152,    30,    49,    50,     5,    49,    50,    51,
      52,    18,    68,    34,    57,   165,    59,    38,    48,    68,
     185,    42,   151,    68,   153,   208,   209,   210,    35,    48,
     213,    28,     5,    24,   125,     5,   186,    10,    11,    26,
      27,    18,    49,    50,    51,    52,   229,    18,   139,   140,
     141,   142,   143,   144,    23,   205,   206,    48,    35,     7,
      32,     5,    69,     5,    35,     5,    10,    11,    59,     3,
      61,    62,    63,    64,    51,    52,    48,    32,    49,    40,
      51,    52,    58,    68,    33,    31,    54,    59,     5,    61,
      62,    63,    64,    48,    55,    56,    56,   226,   227,    48,
      53,    37,    40,    68,    59,    66,    61,    62,    63,    64,
      59,    47,    61,    62,    63,    64,    37,    53,    56,     7,
      53,    57,    20,    21,    22,    68,    47,    48,    66,    41,
       5,    67,    57,    48,    66,    53,    55,    68,    59,     5,
      61,    62,    63,    64,    59,    48,    61,    62,    63,    64,
      22,    29,    67,    48,    17,    54,    59,    53,    61,    62,
      63,    64,    65,    48,    59,    69,    61,    62,    63,    64,
      65,    48,    69,    58,    59,    69,    61,    62,    63,    64,
      53,    57,    59,    69,    61,    62,    63,    64,    17,    54,
      54,    27,    54,    53,    53,    53,    67,    16,   216,   115,
     130,   106,    63,   231,   196
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    11,    71,     5,     0,    53,     8,    44,    72,    74,
      78,    79,     5,    86,     5,    81,    46,    73,    76,    77,
      78,    79,    80,    10,    30,    75,   106,   107,    74,    74,
      48,     9,    48,    28,     5,    87,    88,    23,     7,     5,
      15,    34,    38,    42,    96,    98,    99,   100,   101,   103,
     104,   105,   112,    77,    77,    77,     5,   108,     5,   109,
      19,    41,    89,    90,    91,    75,    75,     3,     3,     5,
       6,    12,    13,    14,    20,    36,    39,    40,    43,    45,
      49,    50,    68,    82,    83,    84,    92,    93,    94,    96,
      97,   113,    58,    31,    54,    56,    68,     3,     5,    92,
       5,    92,    40,    55,    56,    66,    53,    68,    76,    68,
      76,    87,    87,     7,    91,    53,    68,    92,    94,    82,
      66,     5,    85,     3,     5,    68,    93,    93,    93,    94,
      53,    57,    48,    59,    61,    62,    63,    64,    95,    18,
      35,    49,    50,    51,    52,    37,    47,    88,    82,    92,
     114,    32,    55,    65,    92,    96,    92,    99,    19,    21,
      41,   110,   111,    22,    87,    17,    86,   114,    84,    54,
      29,    93,    69,    69,    81,    84,    92,    93,    93,    93,
      93,    93,    93,    94,    94,    53,    58,    69,    98,    92,
      98,    67,    88,    88,    88,    69,    53,    69,    92,    69,
      57,    82,    87,   114,    25,    33,    60,   102,    54,    54,
      54,    53,   110,    17,    24,    84,    53,    92,    92,    27,
      82,    82,    82,    82,    67,    85,    32,    65,    53,    16,
      98,    98,    82,    26,   102
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    70,    71,    72,    73,    74,    74,    74,    75,    75,
      75,    76,    77,    77,    77,    77,    78,    79,    80,    81,
      81,    82,    82,    82,    82,    82,    82,    83,    83,    83,
      83,    83,    84,    84,    85,    85,    86,    86,    87,    87,
      88,    88,    89,    89,    89,    90,    91,    92,    92,    92,
      93,    93,    93,    93,    93,    93,    93,    93,    93,    93,
      93,    94,    94,    94,    94,    94,    94,    94,    95,    95,
      95,    95,    95,    95,    96,    96,    96,    96,    97,    98,
      98,    99,    99,    99,    99,    99,   100,   101,   102,   102,
     103,   103,   104,   105,   106,   107,   108,   109,   110,   110,
     111,   111,   111,   112,   113,   114,   114
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     7,     4,     2,     2,     2,     0,     2,     2,
       0,     2,     2,     2,     2,     0,     3,     3,     3,     5,
       0,     3,     8,     1,     3,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     5,     0,     5,     0,     5,     0,
       3,     1,     1,     2,     1,     2,     2,     1,     1,     1,
       3,     3,     3,     3,     3,     3,     3,     1,     1,     2,
       2,     3,     3,     2,     1,     1,     3,     3,     1,     1,
       1,     1,     1,     1,     1,     3,     4,     2,     1,     3,
       1,     1,     1,     1,     1,     1,     3,     6,     5,     0,
       1,     1,     5,     9,     4,     6,     5,     7,     3,     0,
       4,     4,     4,     4,     4,     3,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* desc_algoritmo: algoritmoTK identificadorTK puntoYComaTK cabecera_alg bloque_alg falgoritmoTK puntoTK  */
#line 140 "parser.y"
                                                                                                      { }
#line 1371 "parser.tab.c"
    break;

  case 3: /* cabecera_alg: decl_globales decl_a_f decl_ent_sal comentarioTK  */
#line 143 "parser.y"
                                                                { }
#line 1377 "parser.tab.c"
    break;

  case 4: /* bloque_alg: bloque comentarioTK  */
#line 146 "parser.y"
                                { }
#line 1383 "parser.tab.c"
    break;

  case 5: /* decl_globales: declaracion_tipo decl_globales  */
#line 149 "parser.y"
                                                 { }
#line 1389 "parser.tab.c"
    break;

  case 6: /* decl_globales: declaracion_const decl_globales  */
#line 150 "parser.y"
                                            { }
#line 1395 "parser.tab.c"
    break;

  case 7: /* decl_globales: %empty  */
#line 151 "parser.y"
          { }
#line 1401 "parser.tab.c"
    break;

  case 8: /* decl_a_f: accion_d decl_a_f  */
#line 154 "parser.y"
                            { }
#line 1407 "parser.tab.c"
    break;

  case 9: /* decl_a_f: funcion_d decl_a_f  */
#line 155 "parser.y"
                             { }
#line 1413 "parser.tab.c"
    break;

  case 10: /* decl_a_f: %empty  */
#line 156 "parser.y"
          { }
#line 1419 "parser.tab.c"
    break;

  case 11: /* bloque: declaraciones instrucciones  */
#line 159 "parser.y"
                                    { }
#line 1425 "parser.tab.c"
    break;

  case 12: /* declaraciones: declaracion_tipo declaraciones  */
#line 162 "parser.y"
                                                 { }
#line 1431 "parser.tab.c"
    break;

  case 13: /* declaraciones: declaracion_const declaraciones  */
#line 163 "parser.y"
                                            { }
#line 1437 "parser.tab.c"
    break;

  case 14: /* declaraciones: declaracion_var declaraciones  */
#line 164 "parser.y"
                                            { }
#line 1443 "parser.tab.c"
    break;

  case 15: /* declaraciones: %empty  */
#line 165 "parser.y"
          { }
#line 1449 "parser.tab.c"
    break;

  case 16: /* declaracion_tipo: tipoTK lista_d_tipo ftipoTK  */
#line 169 "parser.y"
                                              { }
#line 1455 "parser.tab.c"
    break;

  case 17: /* declaracion_const: constTK lista_d_cte fconstTK  */
#line 172 "parser.y"
                                                { }
#line 1461 "parser.tab.c"
    break;

  case 18: /* declaracion_var: varTK lista_d_var fvarTK  */
#line 175 "parser.y"
                                          { }
#line 1467 "parser.tab.c"
    break;

  case 19: /* lista_d_tipo: identificadorTK igualTK d_tipo puntoYComaTK lista_d_tipo  */
#line 179 "parser.y"
                                                                         { }
#line 1473 "parser.tab.c"
    break;

  case 20: /* lista_d_tipo: %empty  */
#line 180 "parser.y"
          { }
#line 1479 "parser.tab.c"
    break;

  case 21: /* d_tipo: tuplaTK lista_campos ftuplaTK  */
#line 183 "parser.y"
                                      { }
#line 1485 "parser.tab.c"
    break;

  case 22: /* d_tipo: tablaTK corcheteAbiertoTK expresion_t subrangoTK expresion_t corcheteCerradoTK deTK d_tipo  */
#line 184 "parser.y"
                                                                                                     { }
#line 1491 "parser.tab.c"
    break;

  case 23: /* d_tipo: identificadorTK  */
#line 185 "parser.y"
                          { }
#line 1497 "parser.tab.c"
    break;

  case 24: /* d_tipo: expresion_t subrangoTK expresion_t  */
#line 186 "parser.y"
                                             { }
#line 1503 "parser.tab.c"
    break;

  case 25: /* d_tipo: refTK d_tipo  */
#line 187 "parser.y"
                       { }
#line 1509 "parser.tab.c"
    break;

  case 26: /* d_tipo: tipo_base  */
#line 188 "parser.y"
                    { }
#line 1515 "parser.tab.c"
    break;

  case 27: /* tipo_base: enteroTK  */
#line 191 "parser.y"
                    { }
#line 1521 "parser.tab.c"
    break;

  case 28: /* tipo_base: booleanoTK  */
#line 192 "parser.y"
                     { }
#line 1527 "parser.tab.c"
    break;

  case 29: /* tipo_base: caracterTK  */
#line 193 "parser.y"
                     { }
#line 1533 "parser.tab.c"
    break;

  case 30: /* tipo_base: realTK  */
#line 194 "parser.y"
                 { }
#line 1539 "parser.tab.c"
    break;

  case 31: /* tipo_base: cadenaTK  */
#line 195 "parser.y"
                   { }
#line 1545 "parser.tab.c"
    break;

  case 32: /* expresion_t: expresion  */
#line 198 "parser.y"
                       { }
#line 1551 "parser.tab.c"
    break;

  case 33: /* expresion_t: literalTK  */
#line 199 "parser.y"
                    { }
#line 1557 "parser.tab.c"
    break;

  case 34: /* lista_campos: identificadorTK dosPuntosTK d_tipo puntoYComaTK lista_campos  */
#line 202 "parser.y"
                                                                           { }
#line 1563 "parser.tab.c"
    break;

  case 35: /* lista_campos: %empty  */
#line 203 "parser.y"
          { }
#line 1569 "parser.tab.c"
    break;

  case 36: /* lista_d_cte: identificadorTK igualTK literalTK puntoYComaTK lista_d_cte  */
#line 207 "parser.y"
                                                                        { }
#line 1575 "parser.tab.c"
    break;

  case 37: /* lista_d_cte: %empty  */
#line 208 "parser.y"
          { }
#line 1581 "parser.tab.c"
    break;

  case 38: /* lista_d_var: lista_id dosPuntosTK d_tipo puntoYComaTK lista_d_var  */
#line 211 "parser.y"
                                                                    { }
#line 1587 "parser.tab.c"
    break;

  case 39: /* lista_d_var: %empty  */
#line 212 "parser.y"
          { }
#line 1593 "parser.tab.c"
    break;

  case 40: /* lista_id: identificadorTK comaTK lista_id  */
#line 215 "parser.y"
                                          { }
#line 1599 "parser.tab.c"
    break;

  case 41: /* lista_id: identificadorTK  */
#line 216 "parser.y"
                          { }
#line 1605 "parser.tab.c"
    break;

  case 42: /* decl_ent_sal: decl_ent  */
#line 219 "parser.y"
                       { }
#line 1611 "parser.tab.c"
    break;

  case 43: /* decl_ent_sal: decl_ent decl_sal  */
#line 220 "parser.y"
                            { }
#line 1617 "parser.tab.c"
    break;

  case 44: /* decl_ent_sal: decl_sal  */
#line 221 "parser.y"
                   { }
#line 1623 "parser.tab.c"
    break;

  case 45: /* decl_ent: entTK lista_d_var  */
#line 224 "parser.y"
                            { }
#line 1629 "parser.tab.c"
    break;

  case 46: /* decl_sal: salTK lista_d_var  */
#line 227 "parser.y"
                            { }
#line 1635 "parser.tab.c"
    break;

  case 47: /* expresion: exp_a  */
#line 231 "parser.y"
                 { }
#line 1641 "parser.tab.c"
    break;

  case 48: /* expresion: exp_b  */
#line 232 "parser.y"
                { }
#line 1647 "parser.tab.c"
    break;

  case 49: /* expresion: funcion_ll  */
#line 233 "parser.y"
                     { }
#line 1653 "parser.tab.c"
    break;

  case 50: /* exp_a: exp_a operadorSumaTK exp_a  */
#line 236 "parser.y"
                                  { }
#line 1659 "parser.tab.c"
    break;

  case 51: /* exp_a: exp_a operadorRestaTK exp_a  */
#line 237 "parser.y"
                                      { }
#line 1665 "parser.tab.c"
    break;

  case 52: /* exp_a: exp_a operadorProductoTK exp_a  */
#line 238 "parser.y"
                                         { }
#line 1671 "parser.tab.c"
    break;

  case 53: /* exp_a: exp_a operadorDivisionTK exp_a  */
#line 239 "parser.y"
                                         { }
#line 1677 "parser.tab.c"
    break;

  case 54: /* exp_a: exp_a modTK exp_a  */
#line 240 "parser.y"
                            { }
#line 1683 "parser.tab.c"
    break;

  case 55: /* exp_a: exp_a divTK exp_a  */
#line 241 "parser.y"
                            { }
#line 1689 "parser.tab.c"
    break;

  case 56: /* exp_a: parentesisAbiertoTK exp_a parentesisCerradoTK  */
#line 242 "parser.y"
                                                        { }
#line 1695 "parser.tab.c"
    break;

  case 57: /* exp_a: operando  */
#line 243 "parser.y"
                   { }
#line 1701 "parser.tab.c"
    break;

  case 58: /* exp_a: literalTK  */
#line 244 "parser.y"
                    { }
#line 1707 "parser.tab.c"
    break;

  case 59: /* exp_a: operadorRestaTK exp_a  */
#line 245 "parser.y"
                                { }
#line 1713 "parser.tab.c"
    break;

  case 60: /* exp_a: operadorSumaTK exp_a  */
#line 246 "parser.y"
                               { }
#line 1719 "parser.tab.c"
    break;

  case 61: /* exp_b: exp_b yTK exp_b  */
#line 249 "parser.y"
                       { }
#line 1725 "parser.tab.c"
    break;

  case 62: /* exp_b: exp_b oTK exp_b  */
#line 250 "parser.y"
                          { }
#line 1731 "parser.tab.c"
    break;

  case 63: /* exp_b: noTK exp_b  */
#line 251 "parser.y"
                      { }
#line 1737 "parser.tab.c"
    break;

  case 64: /* exp_b: operando_b  */
#line 252 "parser.y"
                     { }
#line 1743 "parser.tab.c"
    break;

  case 65: /* exp_b: literalTK  */
#line 253 "parser.y"
                    { }
#line 1749 "parser.tab.c"
    break;

  case 66: /* exp_b: expresion oprel expresion  */
#line 254 "parser.y"
                                    { }
#line 1755 "parser.tab.c"
    break;

  case 67: /* exp_b: parentesisAbiertoTK exp_b parentesisCerradoTK  */
#line 255 "parser.y"
                                                         { }
#line 1761 "parser.tab.c"
    break;

  case 68: /* oprel: operadorMenorTK  */
#line 258 "parser.y"
                       { }
#line 1767 "parser.tab.c"
    break;

  case 69: /* oprel: operadorMayorTK  */
#line 259 "parser.y"
                          { }
#line 1773 "parser.tab.c"
    break;

  case 70: /* oprel: igualTK  */
#line 260 "parser.y"
                  { }
#line 1779 "parser.tab.c"
    break;

  case 71: /* oprel: operadorDistintoTK  */
#line 261 "parser.y"
                             { }
#line 1785 "parser.tab.c"
    break;

  case 72: /* oprel: operadorMayorIgualTK  */
#line 262 "parser.y"
                               { }
#line 1791 "parser.tab.c"
    break;

  case 73: /* oprel: operadorMenorIgualTK  */
#line 263 "parser.y"
                               { }
#line 1797 "parser.tab.c"
    break;

  case 74: /* operando: identificadorTK  */
#line 266 "parser.y"
                          { }
#line 1803 "parser.tab.c"
    break;

  case 75: /* operando: operando puntoTK operando  */
#line 267 "parser.y"
                                    { }
#line 1809 "parser.tab.c"
    break;

  case 76: /* operando: operando corcheteAbiertoTK expresion corcheteCerradoTK  */
#line 268 "parser.y"
                                                                 { }
#line 1815 "parser.tab.c"
    break;

  case 77: /* operando: operando refTK  */
#line 269 "parser.y"
                         { }
#line 1821 "parser.tab.c"
    break;

  case 78: /* operando_b: identificadorTK_b  */
#line 272 "parser.y"
                              { }
#line 1827 "parser.tab.c"
    break;

  case 79: /* instrucciones: instrucciones puntoYComaTK instruccion  */
#line 276 "parser.y"
                                                         { }
#line 1833 "parser.tab.c"
    break;

  case 80: /* instrucciones: instruccion  */
#line 277 "parser.y"
                      { }
#line 1839 "parser.tab.c"
    break;

  case 81: /* instruccion: continuarTK  */
#line 280 "parser.y"
                         { }
#line 1845 "parser.tab.c"
    break;

  case 82: /* instruccion: asignacion  */
#line 281 "parser.y"
                     { }
#line 1851 "parser.tab.c"
    break;

  case 83: /* instruccion: alternativa  */
#line 282 "parser.y"
                      { }
#line 1857 "parser.tab.c"
    break;

  case 84: /* instruccion: iteracion  */
#line 283 "parser.y"
                    { }
#line 1863 "parser.tab.c"
    break;

  case 85: /* instruccion: accion_ll  */
#line 284 "parser.y"
                    { }
#line 1869 "parser.tab.c"
    break;

  case 86: /* asignacion: operando asignacionTK expresion  */
#line 287 "parser.y"
                                            { }
#line 1875 "parser.tab.c"
    break;

  case 87: /* alternativa: siTK expresion entoncesTK instrucciones lista_opciones fsiTK  */
#line 290 "parser.y"
                                                                            { }
#line 1881 "parser.tab.c"
    break;

  case 88: /* lista_opciones: siNoTK expresion entoncesTK instrucciones lista_opciones  */
#line 293 "parser.y"
                                                                         { }
#line 1887 "parser.tab.c"
    break;

  case 89: /* lista_opciones: %empty  */
#line 294 "parser.y"
          { }
#line 1893 "parser.tab.c"
    break;

  case 90: /* iteracion: it_cota_fija  */
#line 297 "parser.y"
                        { }
#line 1899 "parser.tab.c"
    break;

  case 91: /* iteracion: it_cota_exp  */
#line 298 "parser.y"
                      { }
#line 1905 "parser.tab.c"
    break;

  case 92: /* it_cota_exp: mientrasTK expresion hacerTK instrucciones fmientrasTK  */
#line 301 "parser.y"
                                                                    { }
#line 1911 "parser.tab.c"
    break;

  case 93: /* it_cota_fija: paraTK identificadorTK asignacionTK expresion hastaTK expresion hacerTK instrucciones fparaTK  */
#line 304 "parser.y"
                                                                                                              { }
#line 1917 "parser.tab.c"
    break;

  case 94: /* accion_d: accionTK a_cabecera bloque faccionTK  */
#line 308 "parser.y"
                                               { }
#line 1923 "parser.tab.c"
    break;

  case 95: /* funcion_d: funcionTK f_cabecera bloque devTK expresion ffuncionTK  */
#line 311 "parser.y"
                                                                  { }
#line 1929 "parser.tab.c"
    break;

  case 96: /* a_cabecera: identificadorTK parentesisAbiertoTK d_par_form parentesisCerradoTK puntoYComaTK  */
#line 314 "parser.y"
                                                                                            { }
#line 1935 "parser.tab.c"
    break;

  case 97: /* f_cabecera: identificadorTK parentesisAbiertoTK lista_d_var parentesisCerradoTK devTK d_tipo puntoYComaTK  */
#line 317 "parser.y"
                                                                                                          { }
#line 1941 "parser.tab.c"
    break;

  case 98: /* d_par_form: d_p_form puntoYComaTK d_par_form  */
#line 320 "parser.y"
                                             { }
#line 1947 "parser.tab.c"
    break;

  case 99: /* d_par_form: %empty  */
#line 321 "parser.y"
          { }
#line 1953 "parser.tab.c"
    break;

  case 100: /* d_p_form: entTK lista_id dosPuntosTK d_tipo  */
#line 324 "parser.y"
                                            { }
#line 1959 "parser.tab.c"
    break;

  case 101: /* d_p_form: salTK lista_id dosPuntosTK d_tipo  */
#line 325 "parser.y"
                                            { }
#line 1965 "parser.tab.c"
    break;

  case 102: /* d_p_form: entSalTK lista_id dosPuntosTK d_tipo  */
#line 326 "parser.y"
                                               { }
#line 1971 "parser.tab.c"
    break;

  case 103: /* accion_ll: identificadorTK parentesisAbiertoTK l_ll parentesisCerradoTK  */
#line 329 "parser.y"
                                                                        { }
#line 1977 "parser.tab.c"
    break;

  case 104: /* funcion_ll: identificadorTK parentesisAbiertoTK l_ll parentesisCerradoTK  */
#line 332 "parser.y"
                                                                         { }
#line 1983 "parser.tab.c"
    break;

  case 105: /* l_ll: expresion comaTK l_ll  */
#line 335 "parser.y"
                            { }
#line 1989 "parser.tab.c"
    break;

  case 106: /* l_ll: expresion  */
#line 336 "parser.y"
                    { }
#line 1995 "parser.tab.c"
    break;


#line 1999 "parser.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 340 "parser.y"



int main(int argc, char **argv){
	#if defined YYDEBUG
	yydebug=1;
	#endif
	++argv, --argc;
	if (argc > 0)
		yyin = fopen(argv[0], "r");
	else
		yyin = stdin;
	tc = nuevaTablaDeConstantes();
	yyparse();
	imprimeTablaDeConstantes(tc);
}


void yyerror(char * s){
	printf("\tBISON: ERROR, %s\n", s);
}
