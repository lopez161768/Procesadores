/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    literalTK = 258,               /* literalTK  */
    nombreCteTK = 259,             /* nombreCteTK  */
    identificadorTK = 260,         /* identificadorTK  */
    identificadorTK_b = 261,       /* identificadorTK_b  */
    comentarioTK = 262,            /* comentarioTK  */
    constTK = 263,                 /* constTK  */
    fconstTK = 264,                /* fconstTK  */
    accionTK = 265,                /* accionTK  */
    algoritmoTK = 266,             /* algoritmoTK  */
    booleanoTK = 267,              /* booleanoTK  */
    cadenaTK = 268,                /* cadenaTK  */
    caracterTK = 269,              /* caracterTK  */
    continuarTK = 270,             /* continuarTK  */
    deTK = 271,                    /* deTK  */
    devTK = 272,                   /* devTK  */
    divTK = 273,                   /* divTK  */
    entTK = 274,                   /* entTK  */
    enteroTK = 275,                /* enteroTK  */
    entSalTK = 276,                /* entSalTK  */
    faccionTK = 277,               /* faccionTK  */
    falgoritmoTK = 278,            /* falgoritmoTK  */
    ffuncionTK = 279,              /* ffuncionTK  */
    fmientrasTK = 280,             /* fmientrasTK  */
    fparaTK = 281,                 /* fparaTK  */
    fsiTK = 282,                   /* fsiTK  */
    ftipoTK = 283,                 /* ftipoTK  */
    ftuplaTK = 284,                /* ftuplaTK  */
    funcionTK = 285,               /* funcionTK  */
    fvarTK = 286,                  /* fvarTK  */
    hacerTK = 287,                 /* hacerTK  */
    hastaTK = 288,                 /* hastaTK  */
    mientrasTK = 289,              /* mientrasTK  */
    modTK = 290,                   /* modTK  */
    noTK = 291,                    /* noTK  */
    oTK = 292,                     /* oTK  */
    paraTK = 293,                  /* paraTK  */
    realTK = 294,                  /* realTK  */
    refTK = 295,                   /* refTK  */
    salTK = 296,                   /* salTK  */
    siTK = 297,                    /* siTK  */
    tablaTK = 298,                 /* tablaTK  */
    tipoTK = 299,                  /* tipoTK  */
    tuplaTK = 300,                 /* tuplaTK  */
    varTK = 301,                   /* varTK  */
    yTK = 302,                     /* yTK  */
    igualTK = 303,                 /* igualTK  */
    operadorRestaTK = 304,         /* operadorRestaTK  */
    operadorSumaTK = 305,          /* operadorSumaTK  */
    operadorProductoTK = 306,      /* operadorProductoTK  */
    operadorDivisionTK = 307,      /* operadorDivisionTK  */
    puntoYComaTK = 308,            /* puntoYComaTK  */
    dosPuntosTK = 309,             /* dosPuntosTK  */
    asignacionTK = 310,            /* asignacionTK  */
    puntoTK = 311,                 /* puntoTK  */
    subrangoTK = 312,              /* subrangoTK  */
    comaTK = 313,                  /* comaTK  */
    operadorDistintoTK = 314,      /* operadorDistintoTK  */
    siNoTK = 315,                  /* siNoTK  */
    operadorMayorIgualTK = 316,    /* operadorMayorIgualTK  */
    operadorMenorIgualTK = 317,    /* operadorMenorIgualTK  */
    operadorMenorTK = 318,         /* operadorMenorTK  */
    operadorMayorTK = 319,         /* operadorMayorTK  */
    entoncesTK = 320,              /* entoncesTK  */
    corcheteAbiertoTK = 321,       /* corcheteAbiertoTK  */
    corcheteCerradoTK = 322,       /* corcheteCerradoTK  */
    parentesisAbiertoTK = 323,     /* parentesisAbiertoTK  */
    parentesisCerradoTK = 324      /* parentesisCerradoTK  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 124 "parser.y"

	char* cadena;
	LiteralT literal;
	int entero;

#line 139 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
