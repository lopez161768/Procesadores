#ifndef TABLA_DE_SIMBOLOS_H
#define TABLA_DE_SIMBOLOS_H

#include <stdbool.h>
#include "literal.h"

// variables: nombre y tipo
// constantes: nombre, tipo y valor 
// acciones: nombre, num de parametros: nombre, tipo
// funciones: nombre, tipo de parametro (ent)
// tipos: tabla, alias
// literales: valor y tipo

typedef struct celda {
	char * nombre;
	LiteralT valor;
	struct celda * sig;	
} Celda;

typedef Celda * TablaDeSimbolos;

TablaDeSimbolos nuevaTablaDeSimbolos(void);
bool insertaSimbolo(TablaDeSimbolos *, char *, LiteralT);
void imprimeTablaDeSimbolos(TablaDeSimbolos);

#endif
