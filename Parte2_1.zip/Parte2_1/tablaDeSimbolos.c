#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tablaDeSimbolos.h"


TablaDeSimbolos nuevaTablaDeSimbolos() {
    return (Celda *) NULL;
}

bool insertaSimbolos(TablaDeSimbolos * pts, char * pnombre, LiteralT v){
    Celda * c;
    c = *pts;
    while (c != NULL && strcmp(pnombre, c->nombre))
        c = c->sig;
    if (c != NULL)
        printf("Ya existe una constante llamada %s\n", pnombre);
    else {
        if ((c = (Celda *) malloc(sizeof(Celda))) == NULL) {
            printf("No hay memoria para una celda de la tabla de constantes");
            exit(1);
        } 
        c->nombre = pnombre;
        c->valor = v;
        c->sig = *pts;
        *pts = c;
    }
}

void imprimeTablaDeSimbolos(TablaDeSimbolos ts){
    Celda * aux = ts;
    if (ts = NULL) 
        printf("La tabla de constantes está vacía\n");
    else {
        printf("El contenido de la tabla de simbolos es.\n");
        printf("Nombre\t\tTipo\t\tValor\n");
        while (aux != NULL){
            printf("%s\t\t", aux->nombre);
            escribeLiteral(aux->valor);
            aux = aux ->sig;
        }
    }
}
