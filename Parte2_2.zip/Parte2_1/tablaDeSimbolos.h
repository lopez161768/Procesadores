#ifndef TABLA_DE_SIMBOLOS_H
#define TABLA_DE_SIMBOLOS_H

#include <stdbool.h>
#include "literal.h"
#include "nombresDeTipos.h"

// tabla estatica de 25-50 nos vale 

// variables: nombre y tipo
// constantes: nombre, tipo y valor 
// acciones: nombre, num de parametros: nombre, tipo
// funciones: nombre, tipo de parametro (ent)
// tipos: tabla, alias
// literales: valor y tipo

typedef struct simbolo {
	char * nombre;
	CategoriaT categoria;
	NombreDeTipoT tipo;	
} Simbolo;

typedef struct  tablaDeSimbolos{
	Simbolo simbolos[50];
	int n;
} TablaDeSimbolos;

TablaDeSimbolos nuevaTablaDeSimbolos(void);
bool insertaSimbolo(TablaDeSimbolos *, char *, NombreDeTipoT;
void imprimeTablaDeSimbolos(TablaDeSimbolos *);

#endif
