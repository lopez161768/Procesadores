/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 24 "parser.y"

	#include "nombresDeTipos.h"
	#include "literal.h"

	typedef struct {
		int place;
		int type;
	} tipoEA;

	typedef struct {
		char* nombres[50];
		int n;
	} ArrayId;


#line 65 "parser.tab.h"

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    literalTK = 258,               /* literalTK  */
    identificadorTK = 259,         /* identificadorTK  */
    identificadorTK_b = 260,       /* identificadorTK_b  */
    comentarioTK = 261,            /* comentarioTK  */
    constTK = 262,                 /* constTK  */
    fconstTK = 263,                /* fconstTK  */
    accionTK = 264,                /* accionTK  */
    algoritmoTK = 265,             /* algoritmoTK  */
    booleanoTK = 266,              /* booleanoTK  */
    cadenaTK = 267,                /* cadenaTK  */
    caracterTK = 268,              /* caracterTK  */
    continuarTK = 269,             /* continuarTK  */
    deTK = 270,                    /* deTK  */
    devTK = 271,                   /* devTK  */
    divTK = 272,                   /* divTK  */
    entTK = 273,                   /* entTK  */
    enteroTK = 274,                /* enteroTK  */
    entSalTK = 275,                /* entSalTK  */
    faccionTK = 276,               /* faccionTK  */
    falgoritmoTK = 277,            /* falgoritmoTK  */
    ffuncionTK = 278,              /* ffuncionTK  */
    fmientrasTK = 279,             /* fmientrasTK  */
    fparaTK = 280,                 /* fparaTK  */
    fsiTK = 281,                   /* fsiTK  */
    ftipoTK = 282,                 /* ftipoTK  */
    ftuplaTK = 283,                /* ftuplaTK  */
    funcionTK = 284,               /* funcionTK  */
    fvarTK = 285,                  /* fvarTK  */
    hacerTK = 286,                 /* hacerTK  */
    hastaTK = 287,                 /* hastaTK  */
    mientrasTK = 288,              /* mientrasTK  */
    modTK = 289,                   /* modTK  */
    noTK = 290,                    /* noTK  */
    oTK = 291,                     /* oTK  */
    paraTK = 292,                  /* paraTK  */
    realTK = 293,                  /* realTK  */
    refTK = 294,                   /* refTK  */
    salTK = 295,                   /* salTK  */
    siTK = 296,                    /* siTK  */
    tablaTK = 297,                 /* tablaTK  */
    tipoTK = 298,                  /* tipoTK  */
    tuplaTK = 299,                 /* tuplaTK  */
    varTK = 300,                   /* varTK  */
    yTK = 301,                     /* yTK  */
    igualTK = 302,                 /* igualTK  */
    operadorRestaTK = 303,         /* operadorRestaTK  */
    operadorSumaTK = 304,          /* operadorSumaTK  */
    operadorProductoTK = 305,      /* operadorProductoTK  */
    operadorDivisionTK = 306,      /* operadorDivisionTK  */
    puntoYComaTK = 307,            /* puntoYComaTK  */
    dosPuntosTK = 308,             /* dosPuntosTK  */
    asignacionTK = 309,            /* asignacionTK  */
    puntoTK = 310,                 /* puntoTK  */
    subrangoTK = 311,              /* subrangoTK  */
    comaTK = 312,                  /* comaTK  */
    operadorDistintoTK = 313,      /* operadorDistintoTK  */
    siNoTK = 314,                  /* siNoTK  */
    operadorMayorIgualTK = 315,    /* operadorMayorIgualTK  */
    operadorMenorIgualTK = 316,    /* operadorMenorIgualTK  */
    operadorMenorTK = 317,         /* operadorMenorTK  */
    operadorMayorTK = 318,         /* operadorMayorTK  */
    entoncesTK = 319,              /* entoncesTK  */
    corcheteAbiertoTK = 320,       /* corcheteAbiertoTK  */
    corcheteCerradoTK = 321,       /* corcheteCerradoTK  */
    parentesisAbiertoTK = 322,     /* parentesisAbiertoTK  */
    parentesisCerradoTK = 323      /* parentesisCerradoTK  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 136 "parser.y"

	char* cadena;
	LiteralT literal;
	int entero;
	tipoEA poeA;
	NombreDeTipoT tipo;
	ArrayId lista;

#line 159 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
