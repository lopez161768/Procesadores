/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 11 "parser.y"

	#include <stdio.h>
	#include "tablaDeConstantes.h"

	int yylex(); // Usamos la funcion que se crea gracias a flex
	void yyerror(char *); // Prototipo de una funcion necesaria
	extern FILE* yyin; // Usamos la varible de Flex en la que viene la entrada

	TablaDeConstantes tc; //Es donde guardaremos las constantes
	#define YYDEBUG 1 //Permite activar el modo Debugg de Bison


#line 84 "parser.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_literalTK = 3,                  /* literalTK  */
  YYSYMBOL_identificadorTK = 4,            /* identificadorTK  */
  YYSYMBOL_identificadorTK_b = 5,          /* identificadorTK_b  */
  YYSYMBOL_comentarioTK = 6,               /* comentarioTK  */
  YYSYMBOL_constTK = 7,                    /* constTK  */
  YYSYMBOL_fconstTK = 8,                   /* fconstTK  */
  YYSYMBOL_accionTK = 9,                   /* accionTK  */
  YYSYMBOL_algoritmoTK = 10,               /* algoritmoTK  */
  YYSYMBOL_booleanoTK = 11,                /* booleanoTK  */
  YYSYMBOL_cadenaTK = 12,                  /* cadenaTK  */
  YYSYMBOL_caracterTK = 13,                /* caracterTK  */
  YYSYMBOL_continuarTK = 14,               /* continuarTK  */
  YYSYMBOL_deTK = 15,                      /* deTK  */
  YYSYMBOL_devTK = 16,                     /* devTK  */
  YYSYMBOL_divTK = 17,                     /* divTK  */
  YYSYMBOL_entTK = 18,                     /* entTK  */
  YYSYMBOL_enteroTK = 19,                  /* enteroTK  */
  YYSYMBOL_entSalTK = 20,                  /* entSalTK  */
  YYSYMBOL_faccionTK = 21,                 /* faccionTK  */
  YYSYMBOL_falgoritmoTK = 22,              /* falgoritmoTK  */
  YYSYMBOL_ffuncionTK = 23,                /* ffuncionTK  */
  YYSYMBOL_fmientrasTK = 24,               /* fmientrasTK  */
  YYSYMBOL_fparaTK = 25,                   /* fparaTK  */
  YYSYMBOL_fsiTK = 26,                     /* fsiTK  */
  YYSYMBOL_ftipoTK = 27,                   /* ftipoTK  */
  YYSYMBOL_ftuplaTK = 28,                  /* ftuplaTK  */
  YYSYMBOL_funcionTK = 29,                 /* funcionTK  */
  YYSYMBOL_fvarTK = 30,                    /* fvarTK  */
  YYSYMBOL_hacerTK = 31,                   /* hacerTK  */
  YYSYMBOL_hastaTK = 32,                   /* hastaTK  */
  YYSYMBOL_mientrasTK = 33,                /* mientrasTK  */
  YYSYMBOL_modTK = 34,                     /* modTK  */
  YYSYMBOL_noTK = 35,                      /* noTK  */
  YYSYMBOL_oTK = 36,                       /* oTK  */
  YYSYMBOL_paraTK = 37,                    /* paraTK  */
  YYSYMBOL_realTK = 38,                    /* realTK  */
  YYSYMBOL_refTK = 39,                     /* refTK  */
  YYSYMBOL_salTK = 40,                     /* salTK  */
  YYSYMBOL_siTK = 41,                      /* siTK  */
  YYSYMBOL_tablaTK = 42,                   /* tablaTK  */
  YYSYMBOL_tipoTK = 43,                    /* tipoTK  */
  YYSYMBOL_tuplaTK = 44,                   /* tuplaTK  */
  YYSYMBOL_varTK = 45,                     /* varTK  */
  YYSYMBOL_yTK = 46,                       /* yTK  */
  YYSYMBOL_igualTK = 47,                   /* igualTK  */
  YYSYMBOL_operadorRestaTK = 48,           /* operadorRestaTK  */
  YYSYMBOL_operadorSumaTK = 49,            /* operadorSumaTK  */
  YYSYMBOL_operadorProductoTK = 50,        /* operadorProductoTK  */
  YYSYMBOL_operadorDivisionTK = 51,        /* operadorDivisionTK  */
  YYSYMBOL_puntoYComaTK = 52,              /* puntoYComaTK  */
  YYSYMBOL_dosPuntosTK = 53,               /* dosPuntosTK  */
  YYSYMBOL_asignacionTK = 54,              /* asignacionTK  */
  YYSYMBOL_puntoTK = 55,                   /* puntoTK  */
  YYSYMBOL_subrangoTK = 56,                /* subrangoTK  */
  YYSYMBOL_comaTK = 57,                    /* comaTK  */
  YYSYMBOL_operadorDistintoTK = 58,        /* operadorDistintoTK  */
  YYSYMBOL_siNoTK = 59,                    /* siNoTK  */
  YYSYMBOL_operadorMayorIgualTK = 60,      /* operadorMayorIgualTK  */
  YYSYMBOL_operadorMenorIgualTK = 61,      /* operadorMenorIgualTK  */
  YYSYMBOL_operadorMenorTK = 62,           /* operadorMenorTK  */
  YYSYMBOL_operadorMayorTK = 63,           /* operadorMayorTK  */
  YYSYMBOL_entoncesTK = 64,                /* entoncesTK  */
  YYSYMBOL_corcheteAbiertoTK = 65,         /* corcheteAbiertoTK  */
  YYSYMBOL_corcheteCerradoTK = 66,         /* corcheteCerradoTK  */
  YYSYMBOL_parentesisAbiertoTK = 67,       /* parentesisAbiertoTK  */
  YYSYMBOL_parentesisCerradoTK = 68,       /* parentesisCerradoTK  */
  YYSYMBOL_YYACCEPT = 69,                  /* $accept  */
  YYSYMBOL_desc_algoritmo = 70,            /* desc_algoritmo  */
  YYSYMBOL_cabecera_alg = 71,              /* cabecera_alg  */
  YYSYMBOL_bloque_alg = 72,                /* bloque_alg  */
  YYSYMBOL_decl_globales = 73,             /* decl_globales  */
  YYSYMBOL_decl_a_f = 74,                  /* decl_a_f  */
  YYSYMBOL_bloque = 75,                    /* bloque  */
  YYSYMBOL_declaraciones = 76,             /* declaraciones  */
  YYSYMBOL_declaracion_tipo = 77,          /* declaracion_tipo  */
  YYSYMBOL_declaracion_const = 78,         /* declaracion_const  */
  YYSYMBOL_declaracion_var = 79,           /* declaracion_var  */
  YYSYMBOL_lista_d_tipo = 80,              /* lista_d_tipo  */
  YYSYMBOL_d_tipo = 81,                    /* d_tipo  */
  YYSYMBOL_tipo_base = 82,                 /* tipo_base  */
  YYSYMBOL_expresion_t = 83,               /* expresion_t  */
  YYSYMBOL_lista_campos = 84,              /* lista_campos  */
  YYSYMBOL_lista_d_cte = 85,               /* lista_d_cte  */
  YYSYMBOL_lista_d_var = 86,               /* lista_d_var  */
  YYSYMBOL_lista_id = 87,                  /* lista_id  */
  YYSYMBOL_decl_ent_sal = 88,              /* decl_ent_sal  */
  YYSYMBOL_decl_ent = 89,                  /* decl_ent  */
  YYSYMBOL_decl_sal = 90,                  /* decl_sal  */
  YYSYMBOL_expresion = 91,                 /* expresion  */
  YYSYMBOL_exp_a = 92,                     /* exp_a  */
  YYSYMBOL_exp_b = 93,                     /* exp_b  */
  YYSYMBOL_oprel = 94,                     /* oprel  */
  YYSYMBOL_operando = 95,                  /* operando  */
  YYSYMBOL_operando_b = 96,                /* operando_b  */
  YYSYMBOL_instrucciones = 97,             /* instrucciones  */
  YYSYMBOL_instruccion = 98,               /* instruccion  */
  YYSYMBOL_asignacion = 99,                /* asignacion  */
  YYSYMBOL_alternativa = 100,              /* alternativa  */
  YYSYMBOL_lista_opciones = 101,           /* lista_opciones  */
  YYSYMBOL_iteracion = 102,                /* iteracion  */
  YYSYMBOL_it_cota_exp = 103,              /* it_cota_exp  */
  YYSYMBOL_it_cota_fija = 104,             /* it_cota_fija  */
  YYSYMBOL_accion_d = 105,                 /* accion_d  */
  YYSYMBOL_a_cabecera = 106,               /* a_cabecera  */
  YYSYMBOL_d_par_form = 107,               /* d_par_form  */
  YYSYMBOL_d_p_form = 108,                 /* d_p_form  */
  YYSYMBOL_accion_ll = 109,                /* accion_ll  */
  YYSYMBOL_funcion_ll = 110,               /* funcion_ll  */
  YYSYMBOL_l_ll = 111                      /* l_ll  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   290

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  69
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  43
/* YYNRULES -- Number of rules.  */
#define YYNRULES  103
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  220

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   323


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   159,   159,   162,   165,   168,   169,   170,   173,   174,
     177,   180,   181,   182,   183,   187,   190,   193,   197,   198,
     201,   202,   203,   204,   205,   206,   209,   210,   211,   212,
     213,   216,   217,   220,   221,   225,   226,   229,   237,   240,
     248,   251,   252,   253,   256,   259,   263,   264,   265,   268,
     269,   270,   271,   272,   273,   274,   275,   276,   277,   278,
     281,   282,   283,   284,   285,   286,   287,   290,   291,   292,
     293,   294,   295,   298,   299,   300,   301,   304,   308,   309,
     312,   313,   314,   315,   316,   319,   322,   325,   326,   329,
     330,   333,   336,   340,   346,   352,   353,   356,   357,   358,
     361,   364,   367,   368
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "literalTK",
  "identificadorTK", "identificadorTK_b", "comentarioTK", "constTK",
  "fconstTK", "accionTK", "algoritmoTK", "booleanoTK", "cadenaTK",
  "caracterTK", "continuarTK", "deTK", "devTK", "divTK", "entTK",
  "enteroTK", "entSalTK", "faccionTK", "falgoritmoTK", "ffuncionTK",
  "fmientrasTK", "fparaTK", "fsiTK", "ftipoTK", "ftuplaTK", "funcionTK",
  "fvarTK", "hacerTK", "hastaTK", "mientrasTK", "modTK", "noTK", "oTK",
  "paraTK", "realTK", "refTK", "salTK", "siTK", "tablaTK", "tipoTK",
  "tuplaTK", "varTK", "yTK", "igualTK", "operadorRestaTK",
  "operadorSumaTK", "operadorProductoTK", "operadorDivisionTK",
  "puntoYComaTK", "dosPuntosTK", "asignacionTK", "puntoTK", "subrangoTK",
  "comaTK", "operadorDistintoTK", "siNoTK", "operadorMayorIgualTK",
  "operadorMenorIgualTK", "operadorMenorTK", "operadorMayorTK",
  "entoncesTK", "corcheteAbiertoTK", "corcheteCerradoTK",
  "parentesisAbiertoTK", "parentesisCerradoTK", "$accept",
  "desc_algoritmo", "cabecera_alg", "bloque_alg", "decl_globales",
  "decl_a_f", "bloque", "declaraciones", "declaracion_tipo",
  "declaracion_const", "declaracion_var", "lista_d_tipo", "d_tipo",
  "tipo_base", "expresion_t", "lista_campos", "lista_d_cte", "lista_d_var",
  "lista_id", "decl_ent_sal", "decl_ent", "decl_sal", "expresion", "exp_a",
  "exp_b", "oprel", "operando", "operando_b", "instrucciones",
  "instruccion", "asignacion", "alternativa", "lista_opciones",
  "iteracion", "it_cota_exp", "it_cota_fija", "accion_d", "a_cabecera",
  "d_par_form", "d_p_form", "accion_ll", "funcion_ll", "l_ll", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-137)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-65)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      16,    26,    61,    12,  -137,    15,    62,    66,     9,   105,
      15,    15,    28,   112,    74,    96,   128,   113,   127,     5,
       9,     9,     9,   136,     0,   105,  -137,  -137,   139,  -137,
      99,  -137,    92,   134,   101,   110,  -137,   100,  -137,    20,
     174,    20,    44,   129,  -137,  -137,  -137,  -137,  -137,  -137,
    -137,  -137,  -137,  -137,   116,     9,   128,   128,   190,   140,
    -137,  -137,   137,   169,    39,  -137,  -137,  -137,  -137,  -137,
      20,  -137,    99,   132,   194,    41,    41,    20,   147,  -137,
     144,   213,   111,    21,   -22,  -137,  -137,   128,  -137,    99,
    -137,    20,  -137,   153,   124,   150,   183,  -137,    20,   197,
      20,     5,   104,   186,  -137,  -137,  -137,  -137,    62,    20,
     213,   166,  -137,    46,   178,   204,  -137,  -137,    41,    -3,
      -3,   102,    -9,    66,    46,  -137,  -137,  -137,  -137,  -137,
    -137,    20,    41,    41,    41,    41,    41,    41,    20,    20,
    -137,   181,   201,   154,     5,    20,     5,   213,   -24,   176,
    -137,   128,   128,   128,   182,   200,  -137,  -137,   198,   209,
      99,  -137,   102,  -137,  -137,  -137,  -137,   213,   111,   111,
      -3,    -3,    71,    71,   166,   166,   128,    20,  -137,     4,
     156,    13,  -137,   196,   214,   215,   217,   104,  -137,    46,
     218,  -137,  -137,  -137,    20,    20,   246,    99,    99,    99,
    -137,  -137,   211,   194,   148,   193,  -137,  -137,  -137,  -137,
     263,  -137,     5,     5,    99,    11,    13,  -137,  -137,  -137
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,     0,     0,     1,     7,    36,    19,    14,     9,
       7,     7,     0,     0,     0,     0,    38,     0,     0,     0,
      14,    14,    14,     0,     0,     9,     5,     6,     0,    16,
       0,    15,    40,     0,     0,     0,     4,    73,    80,     0,
       0,     0,     0,    10,    79,    81,    82,    83,    90,    89,
      84,    11,    12,    13,     0,    14,    38,    38,     0,    41,
      43,     8,     0,    57,    73,    77,    27,    30,    28,    26,
       0,    29,     0,     0,    34,     0,     0,     0,     0,    25,
       0,    31,    46,    47,    56,    63,    48,     0,    17,     0,
       2,     0,    57,    73,     0,     0,     0,    76,     0,     0,
       0,     0,    96,     0,    44,    45,     3,    42,    36,     0,
       0,    62,    24,     0,     0,     0,    57,    73,     0,    58,
      59,    46,    47,    19,     0,    69,    70,    71,    72,    67,
      68,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      39,     0,   103,     0,     0,     0,     0,    85,    74,     0,
      78,     0,     0,     0,     0,     0,    93,    35,     0,     0,
       0,    20,     0,    55,    66,    18,    23,    65,    54,    53,
      50,    49,    51,    52,    61,    60,    38,     0,   100,     0,
       0,    88,    75,     0,     0,     0,     0,    96,   101,     0,
       0,    37,   102,    91,     0,     0,     0,     0,     0,     0,
      94,    95,     0,    34,     0,     0,    86,    97,    99,    98,
       0,    33,     0,     0,     0,     0,    88,    21,    92,    87
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -137,  -137,  -137,  -137,    86,   254,   225,   170,    24,   158,
    -137,   159,   -68,  -137,  -111,    78,   175,   -50,   -67,  -137,
    -137,   226,   -38,    40,   -65,  -137,   -19,  -137,  -136,   185,
    -137,  -137,    68,  -137,  -137,  -137,  -137,  -137,   103,  -137,
    -137,  -137,   -98
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     2,     8,    17,     9,    24,    18,    19,    20,    21,
      22,    15,    78,    79,    80,   115,    13,    33,    34,    58,
      59,    60,    81,    82,    83,   131,    84,    85,    43,    44,
      45,    46,   196,    47,    48,    49,    25,    55,   154,   155,
      50,    86,   143
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      42,    94,   159,    96,   112,   111,   104,   105,   179,    37,
     181,   158,   122,   166,   132,    97,     6,    97,    56,    38,
     140,   141,     6,    92,    93,    65,     1,   138,   193,    10,
       3,   133,   110,    99,    10,    10,   218,   139,    39,   110,
      57,   100,    40,   100,   116,   117,    41,   136,   137,    63,
      93,    65,     7,   142,    16,    70,   101,   138,     7,   164,
     147,     4,   149,   101,     5,   101,    12,   139,    75,    76,
      14,   142,   195,   174,   175,    28,   215,   216,   202,   192,
     148,    70,    42,    97,   183,   184,   185,    77,   132,    75,
      76,   -22,   190,   167,    75,    76,    26,    27,    98,    99,
     110,   110,    63,    64,    65,   133,   109,   180,   118,   100,
      66,    67,    68,    77,    23,   119,   120,   121,    69,   132,
      29,    30,   151,    31,   152,    42,   191,    42,   132,   207,
     208,   209,    32,    36,    70,    35,   133,    71,    72,   142,
      54,    73,    62,    74,   153,   133,   217,    75,    76,    87,
     134,   135,   136,   137,    89,   144,   204,   205,   162,   134,
     135,   136,   137,    11,    88,    90,    77,    91,    11,    11,
     163,   125,   168,   169,   170,   171,   172,   173,    95,   212,
      57,   101,   126,   102,   127,   128,   129,   130,   194,   108,
      51,    52,    53,    42,    42,   125,   106,   113,   114,   123,
     124,   117,   138,   125,   145,   -64,   126,   156,   127,   128,
     129,   130,   139,   -47,   126,   -64,   127,   128,   129,   130,
     109,   -32,   178,   125,   -47,   -32,   -47,   -47,   -47,   -47,
     125,   160,   161,   176,   126,   -32,   127,   128,   129,   130,
     125,   126,   182,   127,   128,   129,   130,   146,   125,   197,
     186,   126,   187,   127,   128,   129,   130,   213,   177,   126,
     125,   127,   128,   129,   130,   189,   188,   198,   199,   200,
     203,   126,   206,   127,   128,   129,   130,   210,   214,    61,
     103,   211,   165,   157,   219,   107,   150,     0,     0,     0,
     201
};

static const yytype_int16 yycheck[] =
{
      19,    39,   113,    41,    72,    70,    56,    57,   144,     4,
     146,   109,    77,   124,    17,    39,     7,    39,    18,    14,
      87,    89,     7,     3,     4,     5,    10,    36,    24,     5,
       4,    34,    70,    55,    10,    11,    25,    46,    33,    77,
      40,    65,    37,    65,     3,     4,    41,    50,    51,     3,
       4,     5,    43,    91,    45,    35,    52,    36,    43,    68,
      98,     0,   100,    52,    52,    52,     4,    46,    48,    49,
       4,   109,    59,   138,   139,    47,   212,   213,   189,   177,
      99,    35,   101,    39,   151,   152,   153,    67,    17,    48,
      49,    52,   160,   131,    48,    49,    10,    11,    54,    55,
     138,   139,     3,     4,     5,    34,    67,   145,    67,    65,
      11,    12,    13,    67,     9,    75,    76,    77,    19,    17,
       8,    47,    18,    27,    20,   144,   176,   146,    17,   197,
     198,   199,     4,     6,    35,    22,    34,    38,    39,   177,
       4,    42,     3,    44,    40,    34,   214,    48,    49,    57,
      48,    49,    50,    51,    53,    31,   194,   195,   118,    48,
      49,    50,    51,     5,    30,    55,    67,    67,    10,    11,
      68,    47,   132,   133,   134,   135,   136,   137,     4,    31,
      40,    52,    58,    67,    60,    61,    62,    63,    32,    52,
      20,    21,    22,   212,   213,    47,     6,    65,     4,    52,
      56,     4,    36,    47,    54,    36,    58,    21,    60,    61,
      62,    63,    46,    47,    58,    46,    60,    61,    62,    63,
      67,    52,    68,    47,    58,    56,    60,    61,    62,    63,
      47,    53,    28,    52,    58,    66,    60,    61,    62,    63,
      47,    58,    66,    60,    61,    62,    63,    64,    47,    53,
      68,    58,    52,    60,    61,    62,    63,    64,    57,    58,
      47,    60,    61,    62,    63,    56,    68,    53,    53,    52,
      52,    58,    26,    60,    61,    62,    63,    66,    15,    25,
      55,   203,   123,   108,   216,    59,   101,    -1,    -1,    -1,
     187
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    10,    70,     4,     0,    52,     7,    43,    71,    73,
      77,    78,     4,    85,     4,    80,    45,    72,    75,    76,
      77,    78,    79,     9,    74,   105,    73,    73,    47,     8,
      47,    27,     4,    86,    87,    22,     6,     4,    14,    33,
      37,    41,    95,    97,    98,    99,   100,   102,   103,   104,
     109,    76,    76,    76,     4,   106,    18,    40,    88,    89,
      90,    74,     3,     3,     4,     5,    11,    12,    13,    19,
      35,    38,    39,    42,    44,    48,    49,    67,    81,    82,
      83,    91,    92,    93,    95,    96,   110,    57,    30,    53,
      55,    67,     3,     4,    91,     4,    91,    39,    54,    55,
      65,    52,    67,    75,    86,    86,     6,    90,    52,    67,
      91,    93,    81,    65,     4,    84,     3,     4,    67,    92,
      92,    92,    93,    52,    56,    47,    58,    60,    61,    62,
      63,    94,    17,    34,    48,    49,    50,    51,    36,    46,
      87,    81,    91,   111,    31,    54,    64,    91,    95,    91,
      98,    18,    20,    40,   107,   108,    21,    85,   111,    83,
      53,    28,    92,    68,    68,    80,    83,    91,    92,    92,
      92,    92,    92,    92,    93,    93,    52,    57,    68,    97,
      91,    97,    66,    87,    87,    87,    68,    52,    68,    56,
      81,    86,   111,    24,    32,    59,   101,    53,    53,    53,
      52,   107,    83,    52,    91,    91,    26,    81,    81,    81,
      66,    84,    31,    64,    15,    97,    97,    81,    25,   101
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    69,    70,    71,    72,    73,    73,    73,    74,    74,
      75,    76,    76,    76,    76,    77,    78,    79,    80,    80,
      81,    81,    81,    81,    81,    81,    82,    82,    82,    82,
      82,    83,    83,    84,    84,    85,    85,    86,    86,    87,
      87,    88,    88,    88,    89,    90,    91,    91,    91,    92,
      92,    92,    92,    92,    92,    92,    92,    92,    92,    92,
      93,    93,    93,    93,    93,    93,    93,    94,    94,    94,
      94,    94,    94,    95,    95,    95,    95,    96,    97,    97,
      98,    98,    98,    98,    98,    99,   100,   101,   101,   102,
     102,   103,   104,   105,   106,   107,   107,   108,   108,   108,
     109,   110,   111,   111
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     7,     4,     2,     2,     2,     0,     2,     0,
       2,     2,     2,     2,     0,     3,     3,     3,     5,     0,
       3,     8,     1,     3,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     5,     0,     5,     0,     5,     0,     3,
       1,     1,     2,     1,     2,     2,     1,     1,     1,     3,
       3,     3,     3,     3,     3,     3,     1,     1,     2,     2,
       3,     3,     2,     1,     1,     3,     3,     1,     1,     1,
       1,     1,     1,     1,     3,     4,     2,     1,     3,     1,
       1,     1,     1,     1,     1,     3,     6,     5,     0,     1,
       1,     5,     9,     4,     5,     3,     0,     4,     4,     4,
       4,     4,     3,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* desc_algoritmo: algoritmoTK identificadorTK puntoYComaTK cabecera_alg bloque_alg falgoritmoTK puntoTK  */
#line 159 "parser.y"
                                                                                                      { }
#line 1356 "parser.tab.c"
    break;

  case 3: /* cabecera_alg: decl_globales decl_a_f decl_ent_sal comentarioTK  */
#line 162 "parser.y"
                                                                { }
#line 1362 "parser.tab.c"
    break;

  case 4: /* bloque_alg: bloque comentarioTK  */
#line 165 "parser.y"
                                { }
#line 1368 "parser.tab.c"
    break;

  case 5: /* decl_globales: declaracion_tipo decl_globales  */
#line 168 "parser.y"
                                                 { }
#line 1374 "parser.tab.c"
    break;

  case 6: /* decl_globales: declaracion_const decl_globales  */
#line 169 "parser.y"
                                            { }
#line 1380 "parser.tab.c"
    break;

  case 7: /* decl_globales: %empty  */
#line 170 "parser.y"
          { }
#line 1386 "parser.tab.c"
    break;

  case 8: /* decl_a_f: accion_d decl_a_f  */
#line 173 "parser.y"
                            { }
#line 1392 "parser.tab.c"
    break;

  case 9: /* decl_a_f: %empty  */
#line 174 "parser.y"
          { }
#line 1398 "parser.tab.c"
    break;

  case 10: /* bloque: declaraciones instrucciones  */
#line 177 "parser.y"
                                    { }
#line 1404 "parser.tab.c"
    break;

  case 11: /* declaraciones: declaracion_tipo declaraciones  */
#line 180 "parser.y"
                                                 { }
#line 1410 "parser.tab.c"
    break;

  case 12: /* declaraciones: declaracion_const declaraciones  */
#line 181 "parser.y"
                                            { }
#line 1416 "parser.tab.c"
    break;

  case 13: /* declaraciones: declaracion_var declaraciones  */
#line 182 "parser.y"
                                            { }
#line 1422 "parser.tab.c"
    break;

  case 14: /* declaraciones: %empty  */
#line 183 "parser.y"
          { }
#line 1428 "parser.tab.c"
    break;

  case 15: /* declaracion_tipo: tipoTK lista_d_tipo ftipoTK  */
#line 187 "parser.y"
                                              { }
#line 1434 "parser.tab.c"
    break;

  case 16: /* declaracion_const: constTK lista_d_cte fconstTK  */
#line 190 "parser.y"
                                                { }
#line 1440 "parser.tab.c"
    break;

  case 17: /* declaracion_var: varTK lista_d_var fvarTK  */
#line 193 "parser.y"
                                          { }
#line 1446 "parser.tab.c"
    break;

  case 18: /* lista_d_tipo: identificadorTK igualTK d_tipo puntoYComaTK lista_d_tipo  */
#line 197 "parser.y"
                                                                         { }
#line 1452 "parser.tab.c"
    break;

  case 19: /* lista_d_tipo: %empty  */
#line 198 "parser.y"
          { }
#line 1458 "parser.tab.c"
    break;

  case 20: /* d_tipo: tuplaTK lista_campos ftuplaTK  */
#line 201 "parser.y"
                                      { }
#line 1464 "parser.tab.c"
    break;

  case 21: /* d_tipo: tablaTK corcheteAbiertoTK expresion_t subrangoTK expresion_t corcheteCerradoTK deTK d_tipo  */
#line 202 "parser.y"
                                                                                                     { }
#line 1470 "parser.tab.c"
    break;

  case 22: /* d_tipo: identificadorTK  */
#line 203 "parser.y"
                          { }
#line 1476 "parser.tab.c"
    break;

  case 23: /* d_tipo: expresion_t subrangoTK expresion_t  */
#line 204 "parser.y"
                                             { }
#line 1482 "parser.tab.c"
    break;

  case 24: /* d_tipo: refTK d_tipo  */
#line 205 "parser.y"
                       { }
#line 1488 "parser.tab.c"
    break;

  case 25: /* d_tipo: tipo_base  */
#line 206 "parser.y"
                    { (yyval.tipo)= (yyvsp[0].tipo); }
#line 1494 "parser.tab.c"
    break;

  case 26: /* tipo_base: enteroTK  */
#line 209 "parser.y"
                    { (yyval.tipo)= ENTERO; }
#line 1500 "parser.tab.c"
    break;

  case 27: /* tipo_base: booleanoTK  */
#line 210 "parser.y"
                     { (yyval.tipo)= BOOLEANO; }
#line 1506 "parser.tab.c"
    break;

  case 28: /* tipo_base: caracterTK  */
#line 211 "parser.y"
                     { (yyval.tipo)= CARACTER; }
#line 1512 "parser.tab.c"
    break;

  case 29: /* tipo_base: realTK  */
#line 212 "parser.y"
                 { (yyval.tipo)= REAL; }
#line 1518 "parser.tab.c"
    break;

  case 30: /* tipo_base: cadenaTK  */
#line 213 "parser.y"
                   { (yyval.tipo)= CADENA; }
#line 1524 "parser.tab.c"
    break;

  case 31: /* expresion_t: expresion  */
#line 216 "parser.y"
                       { }
#line 1530 "parser.tab.c"
    break;

  case 32: /* expresion_t: literalTK  */
#line 217 "parser.y"
                    { }
#line 1536 "parser.tab.c"
    break;

  case 33: /* lista_campos: identificadorTK dosPuntosTK d_tipo puntoYComaTK lista_campos  */
#line 220 "parser.y"
                                                                           { }
#line 1542 "parser.tab.c"
    break;

  case 34: /* lista_campos: %empty  */
#line 221 "parser.y"
          { }
#line 1548 "parser.tab.c"
    break;

  case 35: /* lista_d_cte: identificadorTK igualTK literalTK puntoYComaTK lista_d_cte  */
#line 225 "parser.y"
                                                                        { }
#line 1554 "parser.tab.c"
    break;

  case 36: /* lista_d_cte: %empty  */
#line 226 "parser.y"
          { }
#line 1560 "parser.tab.c"
    break;

  case 37: /* lista_d_var: lista_id dosPuntosTK d_tipo puntoYComaTK lista_d_var  */
#line 229 "parser.y"
                                                                    {
	//ponemos los prints de momento porque no hemos hecho la tabla de simbolos aun --> para comprobar que va el var...fvar
 	printf("[lista_id] n=%d", (yyvsp[-4].lista).n);
	for(int i = 0; i<(yyvsp[-4].lista).n; i++){
		printf("%s ", (yyvsp[-4].lista).nombres[i]);	
	}
	printf("tipo (%d)\n", (yyvsp[-2].tipo));
	 }
#line 1573 "parser.tab.c"
    break;

  case 38: /* lista_d_var: %empty  */
#line 237 "parser.y"
          { }
#line 1579 "parser.tab.c"
    break;

  case 39: /* lista_id: identificadorTK comaTK lista_id  */
#line 240 "parser.y"
                                          { 
		(yyval.lista)= (yyvsp[0].lista); 
		for(int i =(yyval.lista).n;i > 0; i--){
			(yyval.lista).nombres[i] = (yyval.lista).nombres[i-1];
		}
		(yyval.lista).nombres[0] = (yyvsp[-2].cadena);
		(yyval.lista).n++;
	}
#line 1592 "parser.tab.c"
    break;

  case 40: /* lista_id: identificadorTK  */
#line 248 "parser.y"
                          { (yyval.lista).n = 1; (yyval.lista).nombres[0]=(yyvsp[0].cadena);}
#line 1598 "parser.tab.c"
    break;

  case 41: /* decl_ent_sal: decl_ent  */
#line 251 "parser.y"
                       { }
#line 1604 "parser.tab.c"
    break;

  case 42: /* decl_ent_sal: decl_ent decl_sal  */
#line 252 "parser.y"
                            { }
#line 1610 "parser.tab.c"
    break;

  case 43: /* decl_ent_sal: decl_sal  */
#line 253 "parser.y"
                   { }
#line 1616 "parser.tab.c"
    break;

  case 44: /* decl_ent: entTK lista_d_var  */
#line 256 "parser.y"
                            { }
#line 1622 "parser.tab.c"
    break;

  case 45: /* decl_sal: salTK lista_d_var  */
#line 259 "parser.y"
                            { }
#line 1628 "parser.tab.c"
    break;

  case 46: /* expresion: exp_a  */
#line 263 "parser.y"
                 { }
#line 1634 "parser.tab.c"
    break;

  case 47: /* expresion: exp_b  */
#line 264 "parser.y"
                { }
#line 1640 "parser.tab.c"
    break;

  case 48: /* expresion: funcion_ll  */
#line 265 "parser.y"
                     { }
#line 1646 "parser.tab.c"
    break;

  case 49: /* exp_a: exp_a operadorSumaTK exp_a  */
#line 268 "parser.y"
                                  { }
#line 1652 "parser.tab.c"
    break;

  case 50: /* exp_a: exp_a operadorRestaTK exp_a  */
#line 269 "parser.y"
                                      { }
#line 1658 "parser.tab.c"
    break;

  case 51: /* exp_a: exp_a operadorProductoTK exp_a  */
#line 270 "parser.y"
                                         { }
#line 1664 "parser.tab.c"
    break;

  case 52: /* exp_a: exp_a operadorDivisionTK exp_a  */
#line 271 "parser.y"
                                         { }
#line 1670 "parser.tab.c"
    break;

  case 53: /* exp_a: exp_a modTK exp_a  */
#line 272 "parser.y"
                            { }
#line 1676 "parser.tab.c"
    break;

  case 54: /* exp_a: exp_a divTK exp_a  */
#line 273 "parser.y"
                            { }
#line 1682 "parser.tab.c"
    break;

  case 55: /* exp_a: parentesisAbiertoTK exp_a parentesisCerradoTK  */
#line 274 "parser.y"
                                                        { }
#line 1688 "parser.tab.c"
    break;

  case 56: /* exp_a: operando  */
#line 275 "parser.y"
                   { }
#line 1694 "parser.tab.c"
    break;

  case 57: /* exp_a: literalTK  */
#line 276 "parser.y"
                    { }
#line 1700 "parser.tab.c"
    break;

  case 58: /* exp_a: operadorRestaTK exp_a  */
#line 277 "parser.y"
                                { }
#line 1706 "parser.tab.c"
    break;

  case 59: /* exp_a: operadorSumaTK exp_a  */
#line 278 "parser.y"
                               { }
#line 1712 "parser.tab.c"
    break;

  case 60: /* exp_b: exp_b yTK exp_b  */
#line 281 "parser.y"
                       { }
#line 1718 "parser.tab.c"
    break;

  case 61: /* exp_b: exp_b oTK exp_b  */
#line 282 "parser.y"
                          { }
#line 1724 "parser.tab.c"
    break;

  case 62: /* exp_b: noTK exp_b  */
#line 283 "parser.y"
                      { }
#line 1730 "parser.tab.c"
    break;

  case 63: /* exp_b: operando_b  */
#line 284 "parser.y"
                     { }
#line 1736 "parser.tab.c"
    break;

  case 64: /* exp_b: literalTK  */
#line 285 "parser.y"
                    { }
#line 1742 "parser.tab.c"
    break;

  case 65: /* exp_b: expresion oprel expresion  */
#line 286 "parser.y"
                                    { }
#line 1748 "parser.tab.c"
    break;

  case 66: /* exp_b: parentesisAbiertoTK exp_b parentesisCerradoTK  */
#line 287 "parser.y"
                                                         { }
#line 1754 "parser.tab.c"
    break;

  case 67: /* oprel: operadorMenorTK  */
#line 290 "parser.y"
                       { }
#line 1760 "parser.tab.c"
    break;

  case 68: /* oprel: operadorMayorTK  */
#line 291 "parser.y"
                          { }
#line 1766 "parser.tab.c"
    break;

  case 69: /* oprel: igualTK  */
#line 292 "parser.y"
                  { }
#line 1772 "parser.tab.c"
    break;

  case 70: /* oprel: operadorDistintoTK  */
#line 293 "parser.y"
                             { }
#line 1778 "parser.tab.c"
    break;

  case 71: /* oprel: operadorMayorIgualTK  */
#line 294 "parser.y"
                               { }
#line 1784 "parser.tab.c"
    break;

  case 72: /* oprel: operadorMenorIgualTK  */
#line 295 "parser.y"
                               { }
#line 1790 "parser.tab.c"
    break;

  case 73: /* operando: identificadorTK  */
#line 298 "parser.y"
                          { }
#line 1796 "parser.tab.c"
    break;

  case 74: /* operando: operando puntoTK operando  */
#line 299 "parser.y"
                                    { }
#line 1802 "parser.tab.c"
    break;

  case 75: /* operando: operando corcheteAbiertoTK expresion corcheteCerradoTK  */
#line 300 "parser.y"
                                                                 { }
#line 1808 "parser.tab.c"
    break;

  case 76: /* operando: operando refTK  */
#line 301 "parser.y"
                         { }
#line 1814 "parser.tab.c"
    break;

  case 77: /* operando_b: identificadorTK_b  */
#line 304 "parser.y"
                              { }
#line 1820 "parser.tab.c"
    break;

  case 78: /* instrucciones: instrucciones puntoYComaTK instruccion  */
#line 308 "parser.y"
                                                         { }
#line 1826 "parser.tab.c"
    break;

  case 79: /* instrucciones: instruccion  */
#line 309 "parser.y"
                      { }
#line 1832 "parser.tab.c"
    break;

  case 80: /* instruccion: continuarTK  */
#line 312 "parser.y"
                         { }
#line 1838 "parser.tab.c"
    break;

  case 81: /* instruccion: asignacion  */
#line 313 "parser.y"
                     { }
#line 1844 "parser.tab.c"
    break;

  case 82: /* instruccion: alternativa  */
#line 314 "parser.y"
                      { }
#line 1850 "parser.tab.c"
    break;

  case 83: /* instruccion: iteracion  */
#line 315 "parser.y"
                    { }
#line 1856 "parser.tab.c"
    break;

  case 84: /* instruccion: accion_ll  */
#line 316 "parser.y"
                    { }
#line 1862 "parser.tab.c"
    break;

  case 85: /* asignacion: operando asignacionTK expresion  */
#line 319 "parser.y"
                                            { }
#line 1868 "parser.tab.c"
    break;

  case 86: /* alternativa: siTK expresion entoncesTK instrucciones lista_opciones fsiTK  */
#line 322 "parser.y"
                                                                            { }
#line 1874 "parser.tab.c"
    break;

  case 87: /* lista_opciones: siNoTK expresion entoncesTK instrucciones lista_opciones  */
#line 325 "parser.y"
                                                                         { }
#line 1880 "parser.tab.c"
    break;

  case 88: /* lista_opciones: %empty  */
#line 326 "parser.y"
          { }
#line 1886 "parser.tab.c"
    break;

  case 89: /* iteracion: it_cota_fija  */
#line 329 "parser.y"
                        { }
#line 1892 "parser.tab.c"
    break;

  case 90: /* iteracion: it_cota_exp  */
#line 330 "parser.y"
                      { }
#line 1898 "parser.tab.c"
    break;

  case 91: /* it_cota_exp: mientrasTK expresion hacerTK instrucciones fmientrasTK  */
#line 333 "parser.y"
                                                                    { }
#line 1904 "parser.tab.c"
    break;

  case 92: /* it_cota_fija: paraTK identificadorTK asignacionTK expresion hastaTK expresion hacerTK instrucciones fparaTK  */
#line 336 "parser.y"
                                                                                                              { }
#line 1910 "parser.tab.c"
    break;

  case 93: /* accion_d: accionTK a_cabecera bloque faccionTK  */
#line 340 "parser.y"
                                               { }
#line 1916 "parser.tab.c"
    break;

  case 94: /* a_cabecera: identificadorTK parentesisAbiertoTK d_par_form parentesisCerradoTK puntoYComaTK  */
#line 346 "parser.y"
                                                                                            { }
#line 1922 "parser.tab.c"
    break;

  case 95: /* d_par_form: d_p_form puntoYComaTK d_par_form  */
#line 352 "parser.y"
                                             { }
#line 1928 "parser.tab.c"
    break;

  case 96: /* d_par_form: %empty  */
#line 353 "parser.y"
          { }
#line 1934 "parser.tab.c"
    break;

  case 97: /* d_p_form: entTK lista_id dosPuntosTK d_tipo  */
#line 356 "parser.y"
                                            { }
#line 1940 "parser.tab.c"
    break;

  case 98: /* d_p_form: salTK lista_id dosPuntosTK d_tipo  */
#line 357 "parser.y"
                                            { }
#line 1946 "parser.tab.c"
    break;

  case 99: /* d_p_form: entSalTK lista_id dosPuntosTK d_tipo  */
#line 358 "parser.y"
                                               { }
#line 1952 "parser.tab.c"
    break;

  case 100: /* accion_ll: identificadorTK parentesisAbiertoTK l_ll parentesisCerradoTK  */
#line 361 "parser.y"
                                                                        { }
#line 1958 "parser.tab.c"
    break;

  case 101: /* funcion_ll: identificadorTK parentesisAbiertoTK l_ll parentesisCerradoTK  */
#line 364 "parser.y"
                                                                         { }
#line 1964 "parser.tab.c"
    break;

  case 102: /* l_ll: expresion comaTK l_ll  */
#line 367 "parser.y"
                            { }
#line 1970 "parser.tab.c"
    break;

  case 103: /* l_ll: expresion  */
#line 368 "parser.y"
                    { }
#line 1976 "parser.tab.c"
    break;


#line 1980 "parser.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 372 "parser.y"



int main(int argc, char **argv){
	#if defined YYDEBUG
	yydebug=1;
	#endif
	++argv, --argc;
	if (argc > 0)
		yyin = fopen(argv[0], "r");
	else
		yyin = stdin;
	tc = nuevaTablaDeConstantes();
	yyparse();
	imprimeTablaDeConstantes(tc);
}


void yyerror(char * s){
	printf("\tBISON: ERROR, %s\n", s);
}
