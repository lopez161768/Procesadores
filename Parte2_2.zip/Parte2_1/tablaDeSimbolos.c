#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tablaDeSimbolos.h"


TablaDeSimbolos nuevaTablaDeSimbolos() {
    ts->n = 0;
}

bool insertaSimbolos(TablaDeSimbolos * pts, char * pnombre, NombreDeTipoT tipo){
    
}

void imprimeTablaDeSimbolos(TablaDeSimbolos ts){
    if (ts->n = 0) 
        printf("La tabla de constantes está vacía\n");
    else {
        printf("El contenido de la tabla de simbolos es.\n");
        printf("Nombre\t\tTipo\t\tValor\n"); //valor aun falta por poner en el struct del .h
        for(int i = 0; i<ts->n;i++{
            printf("%s\t\t%s\t\t", ts->simbolos[i].nombre, ts->simbolos[i].tipo);
            escribeLiteral(aux->valor);
            aux = aux ->sig;
        }
    }
}
