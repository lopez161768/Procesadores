#ifndef TABLA_DE_SIMBOLOS_H
#define TABLA_DE_SIMBOLOS_H

#include <stdbool.h>
#include "nombresDeTipos.h"
#include "nombresDeCategorias.h"

// tabla estatica de 25-50 nos vale 

// variables: nombre y tipo
// constantes: nombre, tipo y valor 
// acciones: nombre, num de parametros: nombre, tipo
// funciones: nombre, tipo de parametro (ent)
// tipos: tabla, alias
// literales: valor y tipo

// representa una fila de la tabla
typedef struct simbolo {
	char * nombre;
	NombreDeCategoriaT categoria;
	NombreDeTipoT tipo;	
} Simbolo;

typedef struct  tablaDeSimbolos{
	Simbolo simbolos[50];
	int n;
} TablaDeSimbolos;


TablaDeSimbolos nuevaTablaDeSimbolos(void);

bool insertarSimbolo(TablaDeSimbolos *, char *, NombreDeCategoriaT, NombreDeTipoT);

void imprimirTablaDeSimbolos(TablaDeSimbolos);

#endif
