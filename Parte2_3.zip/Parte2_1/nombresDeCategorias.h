#ifndef FFF_NOMBRESDECATEGORIAS_H
#define FFF_NOMBRESDECATEGORIAS_H

typedef enum nombreDeCategoriaT {
	VARIABLE,
	CONSTANTE,
	ENTRADA,
	SALIDA,
    ENTRADA_SALIDA,
    ACCION,
    FUNCION
} NombreDeCategoriaT;

#endif
