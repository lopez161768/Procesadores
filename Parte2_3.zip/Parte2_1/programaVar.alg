algoritmo intercambio;
    ent a, b: entero;
    sal a, b: entero;
{Prec: a= A AND b = B}
    var
        aux, aux2, aux3: entero;
    fvar
    aux:= a;
    aux2:= b;
    aux3:= aux
{Post: b=A AND a = B}
falgoritmo.