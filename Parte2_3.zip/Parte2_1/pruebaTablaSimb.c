// Archivo: pruebaTabla.c
// Programa de prueba de la tabla de simbolos, independiente del parser.
// Compilar: gcc -Wall pruebaTabla.c tablaDeSimbolos.c literal.c -o prueba
// Cada prueba escribe OK si el resultado coincide con el esperado y FALLO si no.

#include <stdio.h>
#include <stdbool.h>
#include "tablaDeSimbolos.h"

static int fallos = 0;

// Compara el resultado obtenido con el esperado y lo anota
static void comprobar(const char * descripcion, bool obtenido, bool esperado) {
    if (obtenido == esperado)
        printf("[OK]    %s\n", descripcion);
    else {
        printf("[FALLO] %s (esperado %s, obtenido %s)\n", descripcion,
               esperado ? "true" : "false", obtenido ? "true" : "false");
        fallos++;
    }
}

int main(void) {
    TablaDeSimbolos ts = nuevaTablaDeSimbolos();

    printf("\n--- 1. Tabla recien creada ---\n");
    imprimirTablaDeSimbolos(ts);          // debe decir que esta vacia
    comprobar("tabla nueva con n = 0", ts.n == 0, true);

    printf("\n--- 2. Insertar y combinar entrada/salida ---\n");
    comprobar("a entrada entero", insertarSimbolo(&ts, "a", ENTRADA, ENTERO), true);
    comprobar("a salida entero (pasa a entrada/salida)", insertarSimbolo(&ts, "a", SALIDA, ENTERO), true);
    comprobar("categoria de a es entrada/salida", ts.simbolos[0].categoria == ENTRADA_SALIDA, true);
    comprobar("b salida entero", insertarSimbolo(&ts, "b", SALIDA, ENTERO), true);
    comprobar("b entrada entero (orden inverso)", insertarSimbolo(&ts, "b", ENTRADA, ENTERO), true);
    comprobar("categoria de b es entrada/salida", ts.simbolos[1].categoria == ENTRADA_SALIDA, true);

    printf("\n--- 3. Variable local ---\n");
    comprobar("aux variable entero", insertarSimbolo(&ts, "aux", VARIABLE, ENTERO), true);

    printf("\n--- 4. Duplicados (deben dar error) ---\n");
    comprobar("aux variable otra vez", insertarSimbolo(&ts, "aux", VARIABLE, ENTERO), false);
    comprobar("a entrada otra vez (ya es entrada/salida)", insertarSimbolo(&ts, "a", ENTRADA, ENTERO), false);
    comprobar("aux como entrada (ya era variable)", insertarSimbolo(&ts, "aux", ENTRADA, ENTERO), false);

    printf("\n--- 5. Misma categoria repetida ---\n");
    comprobar("c entrada entero", insertarSimbolo(&ts, "c", ENTRADA, ENTERO), true);
    comprobar("c entrada entero otra vez", insertarSimbolo(&ts, "c", ENTRADA, ENTERO), false);

    printf("\n--- 6. Entrada y salida con distinto tipo (error) ---\n");
    comprobar("d entrada entero", insertarSimbolo(&ts, "d", ENTRADA, ENTERO), true);
    comprobar("d salida real", insertarSimbolo(&ts, "d", SALIDA, REAL), false);
    comprobar("d sigue siendo entrada", ts.simbolos[ts.n - 1].categoria == ENTRADA, true);

    printf("\n--- Tabla final ---\n");
    imprimirTablaDeSimbolos(ts);
    // esperado: a y b entrada/salida, aux variable, c y d entrada; 5 simbolos
    comprobar("la tabla tiene 5 simbolos", ts.n == 5, true);

    printf("\n--- 7. Tabla llena ---\n");
    TablaDeSimbolos llena = nuevaTablaDeSimbolos();
    char nombre[20];
    bool todosBien = true;
    for (int i = 0; i < 50; i++) {
        sprintf(nombre, "v%d", i);
        if (!insertarSimbolo(&llena, nombre, VARIABLE, ENTERO))
            todosBien = false;
    }
    comprobar("se insertan 50 simbolos distintos", todosBien, true);
    comprobar("el simbolo 51 da error de tabla llena", insertarSimbolo(&llena, "v50", VARIABLE, ENTERO), false);
    comprobar("la tabla sigue con 50 simbolos", llena.n == 50, true);

    printf("\n%s (%d fallos)\n", fallos == 0 ? "TODAS LAS PRUEBAS CORRECTAS" : "HAY PRUEBAS FALLIDAS", fallos);
    return fallos == 0 ? 0 : 1;
}
