#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tablaDeSimbolos.h"


TablaDeSimbolos nuevaTablaDeSimbolos() {
    TablaDeSimbolos ts;
    ts.n = 0;

    return ts;
}

bool insertarSimbolo(TablaDeSimbolos * pts, char * pnombre,  NombreDeTipoT tipo){
    // recorrrer la tabla para ver si ya está pnombre
    for (int i = 0; i < pts->n; i++){
        if (strcmp(pnombre, pts->simbolos[i].nombre) == 0) { // strcmp dev 0 si son iguales --> encontrado pnombre en la tabla

            // también hay que cmprobar que son el MISMO TIPO !!!!!
            if(pts->simbolos[i].tipo == tipo) {
                return true;
            }
            // caso de != tipo --> false
            fprintf(stderr, "Error semántico: el identificador '%s' declarado antes con otro tipo.\n", pnombre);
            return false;

        }
    }
    // caso de queesté llena la tabla
    if (pts->n >= 50) {
        fprintf(stderr, "Error: tabla de símbolos llena al intentar insertar '%s'.\n", pnombre);
        return false;
    }

    // insertar nuevo símbolo
    pts->simbolos[pts->n].nombre = strdup(pnombre); // hacemos copia
    pts->simbolos[pts->n].tipo = tipo;
    pts->n++;

    return true;
}



const char* traducirTipo(NombreDeTipoT tipo) {
    switch(tipo){
        case BOOLEANO:      return "booleano";
        case CADENA:        return "cadena";
        case CARACTER:      return "caracter";
        case ENTERO:        return "entero";
        case REAL:          return "real";

        default:            return "desconocido";
    }
}

void imprimirTablaDeSimbolos(TablaDeSimbolos ts){
    // caso de que la tabla está vacía
    if (ts.n == 0) {
        printf("La tabla de símbolos está vacía\n");
    }
    // no vacía
    else {
        printf("El contenido de la tabla de simbolos es:\n");
        printf("Nombre\t\t  Tipo\n"); //valor aun falta por poner en el struct del .h
        printf("-----------------------------------------------------\n");

        for (int i = 0; i < ts.n; i++) {
            printf("%s\t\t %s\n",
                ts.simbolos[i].nombre,
                traducirTipo(ts.simbolos[i].tipo)
            );
        }



    }
}


