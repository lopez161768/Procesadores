#ifndef NOMBRESDECATEGORIAS_H
#define NOMBRESDECATEGORIAS_H

typedef enum nombreDeCategoriaT {
	VARIABLE,
	CONSTANTE,
	ENTRADA,
	SALIDA,
    ENTRADA_SALIDA,
    ACCION,
    FUNCION
} NombreDeCategoriaT;

#endif
