#ifndef TABLADECUADRUPLAS_H
#define TABLADECUADRUPLAS_H

#include "tablaDeSimbolos.h"
#include "nombresDeOperadores.h"


// representa una fila de la tabla
typedef struct cuadrupla {
	NombreDeOperadorT operador;	
    int arg1;
    int arg2;
    int res;
} Cuadrupla;

typedef struct  tablaDeCuadruplas{
	Cuadrupla cuadrupla[50];
	int n;
} TablaDeCuadruplas;


TablaDeCuadruplas nuevaTablaDeCuadruplas(void);

bool gen(TablaDeCuadruplas *, NombreDeOperadorT, int, int, int);

void imprimirTablaDeCuadruplas(TablaDeCuadruplas, TablaDeSimbolos);

int nextQuad(TablaDeCuadruplas *);

#endif