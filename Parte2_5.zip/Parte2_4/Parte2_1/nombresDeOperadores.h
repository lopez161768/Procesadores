#ifndef NOMBRESDEOPERADORES_H
#define NOMBRESDEOPERADORES_H

typedef enum nombreDeOperadorT {
	SUMA,
	RESTA,
	PRODUCTO,
	DIVISION,
	DIV,
    MOD, 
    MENOS
} NombreDeOperadorT;

#endif