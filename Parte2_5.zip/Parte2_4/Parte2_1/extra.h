#ifndef EXTRA_H
#define EXTRA_H


#include "nombresDeTipos.h"
#include "literal.h"

typedef struct {
    int place;
    int type;
} tipoEA;

typedef struct {
    char* nombres[50];
    int n;
} ArrayId;


#endif
