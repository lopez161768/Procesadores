#include "tablaDeCuadruplas.h"
#include <stdio.h>

TablaDeCuadruplas nuevaTablaDeCuadruplas(){
    TablaDeCuadruplas tc;
    tc.n = 0;

    return tc;
}

bool gen(TablaDeCuadruplas *tc, NombreDeOperadorT op, int arg1, int arg2, int res){
    if (tc->n >= 50) {
        fprintf(stderr, "Error: tabla de cuadruplas llena.\n");
        return false;
    }
    else{
        tc->cuadrupla[tc->n].operador = op;
        tc->cuadrupla[tc->n].arg1 = arg1;
        tc->cuadrupla[tc->n].arg2 = arg2;
        tc->cuadrupla[tc->n].res = res;
        tc->n++;
    }
    return true;
}

const char* traducirOperador(NombreDeOperadorT operador) {
    switch(operador){
        case SUMA:      return "+";
        case RESTA:     return "-";
        case PRODUCTO:  return "*";
        case DIVISION:  return "/";
        case DIV:       return "div";
        case MOD:       return "mod";
        case MENOS:     return "-";

        default:            return "desconocido";
    }
}

void imprimirTablaDeCuadruplas(TablaDeCuadruplas tc, TablaDeSimbolos ts){
    // caso de que la tabla estña vacía
    if (tc.n == 0) {
        printf("La tabla de cuadruplas está vacía\n");
    }
    else{
        printf("Tabla de cuadruplas:\n");
        printf("-------------------------------------------------\n");
        
        for(int i = 0; i < tc.n; i++) {
            Cuadrupla c = tc.cuadrupla[i];
            // caso unario
            if (c.arg2 == -1) {
                printf("%d: %s := %s %s \n",
                    i,
                    ts.simbolos[c.res].nombre,
                    traducirOperador(c.operador), 
                    ts.simbolos[c.arg1].nombre
                );
            }
            else{
                printf("%d: %s := %s %s %s \n",
                    i,
                    ts.simbolos[c.res].nombre,
                    ts.simbolos[c.arg1].nombre,
                    traducirOperador(c.operador),
                    ts.simbolos[c.arg2].nombre  
                );
            }

        }
    }
}

int nextQuad(TablaDeCuadruplas *tc){
    return tc->n;
}